export interface ServiceItem {
  id: number;
  title: string;
  description?: string;
  link: string;
  iconName: string;
  badge?: string;
  popular?: boolean;
}

export interface BenefitItem {
  title: string;
  description: string;
  iconName: string;
}

export interface GalleryItem {
  src: string;
  alt: string;
  title: string;
  category: string;
}
