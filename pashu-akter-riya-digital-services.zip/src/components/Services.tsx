import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Target, Layout, ShieldCheck, TrendingUp, Users, Layers, 
  Megaphone, Compass, Sparkles, MessageSquare, ArrowRight 
} from "lucide-react";
import { ServiceItem } from "../types";

interface ServicesProps {
  lang: "bn" | "en";
}

export default function Services({ lang }: ServicesProps) {
  const [filter, setFilter] = useState<"all" | "campaign" | "setup" | "strategy">("all");

  const services: { 
    id: number;
    titleEn: string;
    titleBn: string;
    descBn: string; 
    descEn: string;
    category: "campaign" | "setup" | "strategy"; 
    link: string;
    iconName: string;
    badgeEn?: string;
    badgeBn?: string;
    popular?: boolean;
  }[] = [
    {
      id: 1,
      titleEn: "Facebook Ads",
      titleBn: "ফেসবুক অ্যাডস",
      descEn: "End-to-end configuration of highly targeted paid Facebook ads to reach buyers and scale sales.",
      descBn: "উচ্চ বিক্রয়ের লক্ষ্যে সঠিক টার্গেটেড ফেসবুক পেইড বিজ্ঞাপন পরিচালনা এবং বাজেট অপ্টিমাইজেশন।",
      link: "https://wa.link/q3nip0",
      iconName: "Target",
      badgeEn: "High ROI",
      badgeBn: "উচ্চ রিটার্ন",
      popular: true,
      category: "campaign"
    },
    {
      id: 2,
      titleEn: "Facebook Page Professional Setup",
      titleBn: "ফেসবুক পেজ প্রফেশনাল সেটআপ",
      descEn: "Complete custom page layout configuration, SEO settings, templates, premium description, and setup.",
      descBn: "ব্যবসার জন্য একটি প্রফেশনাল ফেসবুক পেজ তৈরি, কাস্টম কভার, ডেসক্রিপশন এবং আকর্ষণীয় এসইও সেটআপ।",
      link: "https://wa.link/f5sqb3",
      iconName: "Layout",
      badgeEn: "Essential",
      badgeBn: "প্রয়োজনীয়",
      category: "setup"
    },
    {
      id: 3,
      titleEn: "Ads Account Setup",
      titleBn: "অ্যাড অ্যাকাউন্ট সেটআপ",
      descEn: "Setup and configuration of Ads Manager, Business Suite setups, and payment integration configs.",
      descBn: "আপনার বিজ্ঞাপন অ্যাকাউন্ট (Ads Manager) এবং বিজনেস স্যুট নিরাপদ কায়দায় নিখুঁতভাবে সেটআপ।",
      link: "https://wa.link/ecwoj3",
      iconName: "ShieldCheck",
      badgeEn: "Secure",
      badgeBn: "নিরাপদ",
      category: "setup"
    },
    {
      id: 4,
      titleEn: "Ads Campaign & Boost",
      titleBn: "বিজ্ঞাপন ক্যাম্পেইন ও বুস্ট",
      descEn: "Accelerate your local page post engagement, boost click-through rates, and increase message queries.",
      descBn: "পেজের যেকোনো পোস্ট বুস্ট, কাস্টম অডিয়েন্স ক্রিয়েশন এবং বিজ্ঞাপনের মাধ্যমে প্রচুর কাস্টমার নিয়ে আসা।",
      link: "https://wa.link/nyyvs1",
      iconName: "TrendingUp",
      badgeEn: "Instant Boost",
      badgeBn: "দ্রুত বুস্ট",
      popular: true,
      category: "campaign"
    },
    {
      id: 5,
      titleEn: "Follow Growth",
      titleBn: "ফলোয়ার বৃদ্ধি",
      descEn: "Grow authentic and highly relevant followers to build lasting organic presence and credibility.",
      descBn: "আপনার ফেসবুক পেজের ফলোয়ার অরগানিক পদ্ধতিতে এবং সঠিক কায়দায় বৃদ্ধির নিখুঁত ও বিশ্বস্ত কৌশল।",
      link: "https://wa.link/b4g34m",
      iconName: "Users",
      badgeEn: "Organic",
      badgeBn: "অরগানিক",
      category: "campaign"
    },
    {
      id: 6,
      titleEn: "ALL Campaign Service",
      titleBn: "সকল ক্যাম্পেইন সার্ভিস",
      descEn: "All-inclusive, multi-purpose Facebook campaign services optimized for your custom business vertical.",
      descBn: "আপনার ব্যবসার ধরণ অনুযায়ী সব ধরণের প্রফেশনাল বিজ্ঞাপনী সেবা এবং দীর্ঘমেয়াদী ক্যাম্পেইন সুবিধা।",
      link: "https://wa.link/jdsruh",
      iconName: "Layers",
      badgeEn: "All-in-One",
      badgeBn: "অল-ইন-ওয়ান",
      category: "campaign"
    },
    {
      id: 7,
      titleEn: "Digital Marketing",
      titleBn: "ডিজিটাল মার্কেটিং",
      descEn: "Comprehensive digital marketing strategies custom-built to maximize conversion and engagement.",
      descBn: "আধুনিক ডিজিটাল মার্কেটিং কৌশলের সঠিক প্রয়োগ যাতে আপনার প্রোডাক্ট বা সার্ভিসের ব্রান্ডিং বাড়ে।",
      link: "https://wa.link/mj3o3o",
      iconName: "Megaphone",
      category: "strategy"
    },
    {
      id: 8,
      titleEn: "Branding",
      titleBn: "ব্র্যান্ডিং",
      descEn: "Establish a prominent corporate identity with outstanding custom copy, designs, and campaigns.",
      descBn: "ফেসবুকে আপনার ব্যবসাকে একটি চমৎকার ও বিশ্বস্ত ব্র্যান্ড হিসেবে মানুষের সামনে ফুটিয়ে তোলার কৌশল।",
      link: "https://wa.link/vbimdq",
      iconName: "Compass",
      category: "strategy"
    },
    {
      id: 9,
      titleEn: "Professional Service",
      titleBn: "পেশাদার সার্ভিস",
      descEn: "Full-time expert support, campaign monitoring, daily analysis, and professional delivery.",
      descBn: "প্রতিদিন ক্যাম্পেইন পর্যবেক্ষণ, বাজেট অপ্টিমাইজেশন এবং সার্বিক প্রফেশনাল ম্যানেজমেন্ট সাপোর্ট।",
      link: "https://wa.link/kswqmp",
      iconName: "Sparkles",
      badgeEn: "Premium",
      badgeBn: "প্রিমিয়াম",
      popular: true,
      category: "strategy"
    }
  ];

  const filteredServices = services.filter(
    (s) => filter === "all" || s.category === filter
  );

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "Target": return <Target className="w-5 h-5 text-blue-600" />;
      case "Layout": return <Layout className="w-5 h-5 text-blue-600" />;
      case "ShieldCheck": return <ShieldCheck className="w-5 h-5 text-blue-600" />;
      case "TrendingUp": return <TrendingUp className="w-5 h-5 text-blue-600" />;
      case "Users": return <Users className="w-5 h-5 text-blue-600" />;
      case "Layers": return <Layers className="w-5 h-5 text-blue-600" />;
      case "Megaphone": return <Megaphone className="w-5 h-5 text-blue-600" />;
      case "Compass": return <Compass className="w-5 h-5 text-blue-600" />;
      default: return <Sparkles className="w-5 h-5 text-blue-600" />;
    }
  };

  const categories = [
    { value: "all", labelEn: "All Services", labelBn: "সকল সার্ভিস" },
    { value: "campaign", labelEn: "Ads & Campaigns", labelBn: "বিজ্ঞাপন ও ক্যাম্পেইন" },
    { value: "setup", labelEn: "Setups & Tech", labelBn: "পেজ ও ম্যানেজার সেটআপ" },
    { value: "strategy", labelEn: "Marketing Strategy", labelBn: "মার্কেটিং ও ব্র্যান্ডিং" },
  ];

  return (
    <section id="services" className="py-24 bg-[#faf9f6] relative">
      <div className="absolute inset-0 bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] [background-size:32px_32px] opacity-25" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-xs font-extrabold text-blue-600 tracking-widest uppercase block mb-3"
          >
            {lang === "en" ? "WHAT WE DO BEST" : "আমাদের সেরা সার্ভিসসমূহ"}
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="font-display font-bold text-3xl sm:text-4xl md:text-5xl text-slate-900 tracking-tight leading-tight mb-4"
          >
            {lang === "en" 
              ? "High-Converting Facebook Solutions Tailored to Your Brand" 
              : "আপনার ব্যবসার বিক্রয় বাড়াতে আমাদের স্পেশাল ফেসবুক সলিউশন"}
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-slate-600 text-sm sm:text-base md:text-lg"
          >
            {lang === "en"
              ? "Click on any category card to directly chat on WhatsApp and start launching your professional ads campaign instantly."
              : "নিচের যেকোনো সার্ভিসে ক্লিক করলে সরাসরি নির্দিষ্ট সার্ভিস প্রমোট করার জন্য ফেসবুক থেকে আপনি আমাদের হোয়াটসঅ্যাপ পেজে চলে যাবেন।"}
          </motion.p>
        </div>

        {/* Filter Tab System - Banned Patterns Avoided */}
        <div className="flex flex-wrap justify-center gap-2 mb-12 max-w-3xl mx-auto">
          {categories.map((cat) => (
            <button
              key={cat.value}
              onClick={() => setFilter(cat.value as any)}
              className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-bold transition-all duration-300 border ${
                filter === cat.value
                  ? "bg-slate-900 text-[#faf9f6] border-slate-900 shadow-md"
                  : "bg-white text-slate-600 border-slate-200/80 hover:bg-slate-50 hover:text-slate-900"
              }`}
            >
              {lang === "en" ? cat.labelEn : cat.labelBn}
            </button>
          ))}
        </div>

        {/* Services Grid with Animation */}
        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <AnimatePresence mode="popLayout">
            {filteredServices.map((service) => (
              <motion.div
                layout
                key={service.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.3 }}
                whileHover={{ y: -6 }}
                className={`relative flex flex-col justify-between bg-white rounded-2xl border p-6 sm:p-8 transition-all duration-300 hover:shadow-xl hover:shadow-blue-900/5 ${
                  service.popular 
                    ? "border-blue-600/40 shadow-sm" 
                    : "border-slate-200/80"
                }`}
              >
                {/* Popular / Premium Badge */}
                {(service.badgeEn || service.badgeBn) && (
                  <span className={`absolute top-4 right-4 text-[10px] font-extrabold tracking-wider uppercase px-2.5 py-1 rounded-full ${
                    service.popular 
                      ? "bg-blue-100 text-blue-700" 
                      : "bg-slate-100 text-slate-600"
                  }`}>
                    {lang === "en" ? service.badgeEn : service.badgeBn}
                  </span>
                )}

                <div>
                  {/* Icon */}
                  <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center mb-6">
                    {getIcon(service.iconName)}
                  </div>

                  {/* Title & Description */}
                  <h3 className="font-display font-extrabold text-slate-900 text-lg sm:text-xl mb-3 leading-snug">
                    {lang === "en" ? service.titleEn : service.titleBn}
                  </h3>
                  <p className="text-slate-600 text-xs sm:text-sm leading-relaxed mb-6">
                    {lang === "en" ? service.descEn : service.descBn}
                  </p>
                </div>

                {/* Redirect Link trigger CTA */}
                <a
                  href={service.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-full inline-flex items-center justify-center gap-2.5 py-3 px-4 rounded-xl font-bold text-xs sm:text-sm transition-all duration-300 ${
                    service.popular
                      ? "bg-[#1877F2] hover:bg-blue-700 text-white shadow-md shadow-blue-600/10"
                      : "bg-slate-100 hover:bg-slate-200 text-slate-800"
                  } group`}
                >
                  <MessageSquare className="w-4 h-4 fill-current text-current opacity-80" />
                  <span>
                    {lang === "en" ? "Order This Service" : "এই সার্ভিসটি অর্ডার করুন"}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </a>

              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Dynamic CTA at the bottom */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-16 text-center bg-slate-900 rounded-3xl p-8 sm:p-12 relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px] opacity-10 pointer-events-none" />
          <h3 className="font-display font-bold text-2xl sm:text-3xl text-[#faf9f6] mb-4">
            {lang === "en" ? "Need a Fully Customized Ads Campaign Package?" : "আপনার ব্যবসার জন্য কাস্টম ক্যাম্পেইন লাগবে?"}
          </h3>
          <p className="text-slate-300 text-sm sm:text-base max-w-2xl mx-auto mb-8">
            {lang === "en"
              ? "Tell me your exact budget and targets, and let me outline a high-converting Facebook Ads setup from scratch."
              : "আপনার বাজেট এবং লক্ষ্যের কথা আমাকে জানান, আমি আপনাকে লাভজনক ও কাস্টম বিজ্ঞাপনী প্ল্যান তৈরি করে দেব।"}
          </p>
          <a
            href="https://wa.link/jdsruh"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2.5 px-8 py-4 rounded-full bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm sm:text-base transition-all duration-300"
          >
            <MessageSquare className="w-5 h-5 fill-white" />
            <span>{lang === "en" ? "Request Custom Service Package" : "কাস্টম বিজ্ঞাপনী প্যাকেজ নির্ধারণ করুন"}</span>
          </a>
        </motion.div>

      </div>
    </section>
  );
}
