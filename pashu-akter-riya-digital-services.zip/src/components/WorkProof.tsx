import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Maximize2, X, CheckCircle, FileText, Sparkles, ArrowRight } from "lucide-react";

interface WorkProofProps {
  lang: "bn" | "en";
}

interface ProofImage {
  src: string;
  titleEn: string;
  titleBn: string;
  descEn: string;
  descBn: string;
  tagEn: string;
  tagBn: string;
}

export default function WorkProof({ lang }: WorkProofProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const proofImages: ProofImage[] = [
    {
      src: "https://i.ibb.co.com/m5FzzSq3/Screenshot-2026-08-15-15-27-25-757-com-facebook-katana.jpg",
      titleEn: "Active Meta Ads Delivery Proof 1",
      titleBn: "অ্যাক্টিভ মেটা ক্যাম্পেইন ডেলিভারি প্রুফ ১",
      descEn: "Live status of running Facebook ads showing high reach and targeted messaging setup.",
      descBn: "চলমান ফেসবুক বিজ্ঞাপনের লাইভ স্ক্রিনশট যা উচ্চ রিচ ও সঠিক মেসেজিং সেটআপের প্রমাণ দেয়।",
      tagEn: "Active Campaign",
      tagBn: "চলমান ক্যাম্পেইন"
    },
    {
      src: "https://i.ibb.co.com/cKQfw63T/Screenshot-2026-08-15-15-27-19-813-com-facebook-katana.jpg",
      titleEn: "Ads Manager Budget & Conversion",
      titleBn: "অ্যাড ম্যানেজার বাজেট ও কনভার্সন ট্র্যাকিং",
      descEn: "Direct screenshot of real-time ad distribution with optimized metrics on mobile.",
      descBn: "মোবাইলে অপ্টিমাইজড বিজ্ঞাপনের রিয়েল-টাইম অ্যাড ডিস্ট্রিবিউশন এবং ট্র্যাকিং স্ক্রিনশট।",
      tagEn: "Meta Ads Manager",
      tagBn: "মেটা অ্যাড ম্যানেজার"
    },
    {
      src: "https://i.ibb.co.com/39WYt1c8/Screenshot-2026-08-15-15-27-12-809-com-facebook-katana.jpg",
      titleEn: "Client Engagement & Results",
      titleBn: "ক্লায়েন্ট রেসপন্স ও ক্যাম্পেইন রেজাল্ট",
      descEn: "Successful messaging campaign delivering direct conversions and sales inquiries.",
      descBn: "ক্যাম্পেইন সেটআপের পর থেকে কাস্টমারদের মেসেজ ও সরাসরি সেলস বৃদ্ধির প্রমাণ।",
      tagEn: "Conversions & Leads",
      tagBn: "কনভার্সন ও লিডস"
    },
    {
      src: "https://i.ibb.co.com/vv155YBR/Screenshot-2026-08-15-15-26-59-592-com-facebook-katana.jpg",
      titleEn: "Facebook Promotion Insights",
      titleBn: "ফেসবুক প্রোমোশন ইনসাইটস",
      descEn: "Unedited proof of page organic boost combined with targeted messaging strategies.",
      descBn: "সঠিক মেসেজিং স্ট্র্যাটেজি ও বিজ্ঞাপনের নিখুঁত অডিয়েন্স টার্গেটিংয়ের প্রমাণ।",
      tagEn: "Page Promotion",
      tagBn: "পেজ প্রোমোশন"
    },
    {
      src: "https://i.ibb.co.com/ZzvZhZGc/IMG-20260815-152531.jpg",
      titleEn: "Campaign Analytics & Live Spending",
      titleBn: "ক্যাম্পেইন অ্যানালিটিক্স ও লাইভ খরচ",
      descEn: "Budget optimization metrics demonstrating low cost per response and high ROI.",
      descBn: "কম খরচে সর্বোত্তম ফলাফল পাওয়ার বাজেট অপ্টিমাইজেশন ম্যাট্রিক্স স্ক্রিনশট।",
      tagEn: "Budget Optimization",
      tagBn: "বাজেট অপ্টিমাইজেশন"
    },
    {
      src: "https://i.ibb.co.com/FLnwZFXm/IMG-20260815-152612.jpg",
      titleEn: "Meta Professional Page Conversion Dashboard",
      titleBn: "মেটা প্রফেশনাল কনভার্সন ড্যাশবোর্ড",
      descEn: "Dashboard proof of page messaging setup showing automated customer responses.",
      descBn: "অটোমেটেড কাস্টমার রেসপন্স সেটআপের পর মেসেজ কনভার্সন ড্যাশবোর্ড স্ক্রিনশট।",
      tagEn: "Messaging Setup",
      tagBn: "মেসেজিং সেটআপ"
    }
  ];

  return (
    <section id="work-proof" className="py-24 bg-[#faf9f6] relative overflow-hidden">
      {/* Background Decorative Blobs */}
      <div className="absolute top-1/4 left-10 w-72 h-72 bg-emerald-50 rounded-full blur-3xl opacity-50 pointer-events-none" />
      <div className="absolute bottom-1/4 right-10 w-80 h-80 bg-blue-50 rounded-full blur-3xl opacity-50 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-bold uppercase mb-4 border border-emerald-100"
          >
            <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
            <span>{lang === "en" ? "Real Live Proof" : "লাইভ কাজের বাস্তব প্রমাণ"}</span>
          </motion.div>
          
          <h2 className="font-display font-bold text-3xl sm:text-4xl md:text-5xl text-slate-900 tracking-tight leading-tight mb-4">
            {lang === "en" ? "Our Real Work Proof & Results" : "আমাদের কাজের বাস্তব প্রমাণ (Work Proof)"}
          </h2>
          
          <p className="text-slate-600 text-sm sm:text-base md:text-lg">
            {lang === "en"
              ? "Here are unedited, real-time screenshots from our active campaigns and customer messenger panels. Click on any image to view it in full screen."
              : "আমরা যেই লাইভ ক্যাম্পেইন পরিচালনা করি তার বাস্তব স্ক্রিনশট এবং কাস্টমার মেসেঞ্জার প্যানেলের বাস্তব প্রমাণসমূহ নিচে দেওয়া হলো। সম্পূর্ণ বড় আকারে দেখতে যেকোনো ছবিতে ক্লিক করুন।"}
          </p>
        </div>

        {/* Proof Grid (Displaying portrait screenshots elegantly) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {proofImages.map((proof, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -6 }}
              className="group bg-white rounded-2xl overflow-hidden border border-slate-200/80 shadow-sm hover:shadow-xl hover:border-emerald-200 transition-all duration-300 flex flex-col justify-between"
            >
              {/* Image Container preserving vertical aspect ratio without cropping */}
              <div className="relative bg-slate-50 border-b border-slate-100 p-4 flex items-center justify-center overflow-hidden h-[420px]">
                <img
                  src={proof.src}
                  alt={proof.titleEn}
                  className="max-h-full max-w-full object-contain rounded-lg shadow-sm group-hover:scale-[1.02] transition-transform duration-500"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                
                {/* Overlay Hover Effect */}
                <div className="absolute inset-0 bg-slate-950/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <button
                    onClick={() => setSelectedImage(proof.src)}
                    className="p-3.5 rounded-full bg-white text-slate-800 hover:bg-emerald-500 hover:text-white shadow-lg scale-90 group-hover:scale-100 transition-all duration-300 cursor-pointer"
                    aria-label="View Full Image"
                  >
                    <Maximize2 className="w-5 h-5" />
                  </button>
                </div>

                {/* Left Floating Category Badge */}
                <span className="absolute top-6 left-6 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100">
                  {lang === "en" ? proof.tagEn : proof.tagBn}
                </span>
              </div>

              {/* Text Info */}
              <div className="p-6 bg-white">
                <h3 className="font-display font-extrabold text-slate-900 text-base sm:text-lg mb-2 leading-snug group-hover:text-emerald-600 transition-colors">
                  {lang === "en" ? proof.titleEn : proof.titleBn}
                </h3>
                <p className="text-slate-500 text-xs sm:text-sm leading-relaxed">
                  {lang === "en" ? proof.descEn : proof.descBn}
                </p>
                
                {/* Click to Expand Prompt */}
                <button
                  onClick={() => setSelectedImage(proof.src)}
                  className="mt-4 inline-flex items-center gap-1.5 text-xs font-bold text-emerald-600 hover:text-emerald-700 transition-colors cursor-pointer"
                >
                  <span>{lang === "en" ? "View Full Screenshot" : "সম্পূর্ণ স্ক্রিনশট দেখুন"}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Lightbox / Modal for Full Screen Image Display */}
        <AnimatePresence>
          {selectedImage && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
              onClick={() => setSelectedImage(null)}
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute top-4 right-4 p-3 rounded-full bg-white/10 text-white hover:bg-white/20 hover:scale-110 active:scale-95 transition-all cursor-pointer z-50"
                aria-label="Close Fullscreen View"
              >
                <X className="w-6 h-6" />
              </button>
              
              {/* Image Frame - Allowing maximum height/width with scroll if needed */}
              <motion.div
                initial={{ scale: 0.95 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0.95 }}
                className="relative max-w-3xl max-h-[90vh] w-full h-full overflow-auto rounded-xl flex items-center justify-center p-2"
                onClick={(e) => e.stopPropagation()}
              >
                <img
                  src={selectedImage}
                  alt="Work Proof Screenshot"
                  className="max-w-full max-h-[85vh] object-contain rounded-lg shadow-2xl border border-white/10"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
