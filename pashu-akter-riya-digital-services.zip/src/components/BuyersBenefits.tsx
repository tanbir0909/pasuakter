import { motion } from "motion/react";
import { Headphones, CalendarDays, Zap, Clock, ShieldCheck, HeartHandshake } from "lucide-react";

interface BuyersBenefitsProps {
  lang: "bn" | "en";
}

export default function BuyersBenefits({ lang }: BuyersBenefitsProps) {
  const benefits = [
    {
      icon: <Headphones className="w-8 h-8 text-[#1877F2]" />,
      titleEn: "24/7 Premium Support",
      titleBn: "২৪/৭ লাইভ সাপোর্ট সুবিধা",
      descEn: "We are always responsive on WhatsApp to update, monitor, and guide you through your active Facebook campaigns.",
      descBn: "যেকোনো প্রয়োজনে আমরা সব সময় আপনার পাশে আছি। ক্যাম্পেইন চলাকালীন দিন-রাত যেকোনো সময় মেসেজ বা কল দিতে পারেন।",
      badgeEn: "Always Active",
      badgeBn: "সব সময় সচল"
    },
    {
      icon: <CalendarDays className="w-8 h-8 text-emerald-600" />,
      titleEn: "On-Time Secure Delivery",
      titleBn: "সঠিক সময়ে কাজের নিশ্চয়তা",
      descEn: "We respect your business timeline. All setups, ads campaigns, and page optimizations are delivered on schedule.",
      descBn: "আপনার ব্যবসার মূল্যবান সময়কে আমরা শ্রদ্ধা করি। নির্দিষ্ট সময়ের ভেতরে সমস্ত কাজ বুঝিয়ে দেওয়ার শতভাগ রেকর্ড আমাদের রয়েছে।",
      badgeEn: "Guaranteed",
      badgeBn: "১০০% নিশ্চিত"
    },
    {
      icon: <Zap className="w-8 h-8 text-amber-500" />,
      titleEn: "Super Fast Campaign Delivery",
      titleBn: "সুপার ফাস্ট ক্যাম্পেইন ডেলিভারি",
      descEn: "Need urgent promotion? We specialize in quick-turnaround campaign setup so you start receiving leads within hours.",
      descBn: "জরুরি প্রচারণার প্রয়োজন? আমরা মাত্র কয়েক ঘন্টার ভেতর সম্পূর্ণ অ্যাড ক্যাম্পেইন ও বুস্টিং সেটআপ সম্পন্ন করি যাতে বিক্রি দ্রুত বাড়ে।",
      badgeEn: "Express Setup",
      badgeBn: "দ্রুততম সেটআপ"
    }
  ];

  return (
    <section id="benefits" className="py-24 bg-white relative overflow-hidden">
      {/* Decorative vector overlays */}
      <div className="absolute top-1/2 left-0 w-64 h-64 bg-slate-100 rounded-full blur-3xl opacity-40 pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-50 rounded-full blur-3xl opacity-30 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 text-slate-800 text-xs font-bold uppercase mb-4 border border-slate-200/50"
          >
            <HeartHandshake className="w-3.5 h-3.5 text-[#1877F2]" />
            <span>{lang === "en" ? "My Customer Guarantees" : "ক্রেতাদের জন্য আমাদের প্রতিশ্রুতি"}</span>
          </motion.div>
          
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="font-display font-bold text-3xl sm:text-4xl md:text-5xl text-slate-900 tracking-tight leading-tight mb-4"
          >
            {lang === "en" 
              ? "Why Work with Pashu Akter Riya?" 
              : "কেন আপনার ফেসবুক ক্যাম্পেইনের জন্য আমাদের বেছে নিবেন?"}
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-slate-600 text-sm sm:text-base md:text-lg"
          >
            {lang === "en"
              ? "We prioritize absolute transparency, premium campaign delivery, and active communication to build your brand authority."
              : "আমরা শতভাগ স্বচ্ছতা, সঠিক কাস্টমার টার্গেটিং এবং নিয়মিত আপডেট দেওয়ার মাধ্যমে বিশ্বস্ততার সাথে ব্যবসা বৃদ্ধিতে সাহায্য করি।"}
          </motion.p>
        </div>

        {/* Benefits Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
              className="bg-[#faf9f6] p-8 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between hover:border-[#1877F2]/40 hover:shadow-lg hover:shadow-slate-200/40 transition-all duration-300"
            >
              <div>
                {/* Header info */}
                <div className="flex items-center justify-between mb-6">
                  <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
                    {benefit.icon}
                  </div>
                  <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-100">
                    {lang === "en" ? benefit.badgeEn : benefit.badgeBn}
                  </span>
                </div>

                {/* Title */}
                <h3 className="font-display font-extrabold text-slate-900 text-lg sm:text-xl mb-3 leading-snug">
                  {lang === "en" ? benefit.titleEn : benefit.titleBn}
                </h3>

                {/* Description */}
                <p className="text-slate-600 text-xs sm:text-sm leading-relaxed mb-6">
                  {lang === "en" ? benefit.descEn : benefit.descBn}
                </p>
              </div>

              {/* Verified Badge */}
              <div className="flex items-center gap-2 pt-4 border-t border-slate-200/50">
                <Clock className="w-4 h-4 text-slate-400" />
                <span className="text-xs font-semibold text-slate-500">
                  {lang === "en" ? "Verified Quality Service" : "যাচাইকৃত প্রফেশনাল সার্ভিস"}
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom Trust Row */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mt-16 flex flex-wrap justify-center items-center gap-x-8 gap-y-4 py-6 border-y border-slate-200/60 text-slate-600"
        >
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#1877F2]" />
            <span className="text-xs sm:text-sm font-bold">{lang === "en" ? "100% Secure Ads Payment" : "শতভাগ নিরাপদ পেমেন্ট সাপোর্ট"}</span>
          </div>
          <div className="w-1.5 h-1.5 rounded-full bg-slate-300 hidden sm:block" />
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <span className="text-xs sm:text-sm font-bold">{lang === "en" ? "Custom Target Audiences" : "নিখুঁত টার্গেটেড কাস্টমার"}</span>
          </div>
          <div className="w-1.5 h-1.5 rounded-full bg-slate-300 hidden sm:block" />
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-500" />
            <span className="text-xs sm:text-sm font-bold">{lang === "en" ? "Experienced Ad Managers" : "অভিজ্ঞ অ্যাড ম্যানেজার টিম"}</span>
          </div>
        </motion.div>

      </div>
    </section>
  );
}
