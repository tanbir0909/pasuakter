import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowRight, MessageSquare, Zap, ShieldCheck, Award, Flame, Users, Sparkles } from "lucide-react";

interface HeroProps {
  lang: "bn" | "en";
  whatsappGeneral: string;
  siteName?: string;
}

export default function Hero({ lang, whatsappGeneral, siteName = "Pashu Akter Riya" }: HeroProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      url: "https://i.ibb.co.com/ZpTp7mQ6/IMG-20260815-204231.jpg",
      titleEn: "Professional Facebook Marketing Specialist",
      titleBn: "প্রফেশনাল ফেসবুক মার্কেটিং স্পেশালিস্ট",
      descEn: "Targeted campaigns and professional page growth architecture designed to scale your business.",
      descBn: "আপনার ব্যবসাকে বৃদ্ধি করতে সঠিক অডিয়েন্স ও মেটা ক্যাম্পেইন স্ট্র্যাটেজি সেটআপ।",
    },
    {
      url: "https://i.ibb.co.com/GDc1Qdk/IMG-20260815-151306.jpg",
      titleEn: "High-Converting Ad Campaigns",
      titleBn: "উচ্চ কনভার্সন অ্যাড ক্যাম্পেইন",
      descEn: "Optimized sales funnels, precise targeting, and detailed diagnostic reporting.",
      descBn: "উচ্চ কনভার্সন সেলস ফানেল এবং মেটা অ্যাড অপ্টিমাইজেশন অডিট রিপোর্ট।",
    },
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const headlineEn = "Scale Your Business to Millions with Facebook Marketing Specialist";
  const headlineBn = "ফেসবুক বিজ্ঞাপনের জাদুতে আপনার ব্যবসাকে নিয়ে যান অনন্য উচ্চতায়";

  const subEn = `Empower your business growth under the guidance of ${siteName}. Get 4+ years of professional Facebook Ads Campaign and strategic page setup experience.`;
  const subBn = `${siteName}-এর হাত ধরে আপনার ব্যবসার প্রচার শুরু করুন। ফেসবুক পেজ প্রফেশনাল সেটআপ, অ্যাড অ্যাকাউন্ট অপ্টিমাইজেশন এবং হাই-কনভার্টিং ক্যাম্পেইনের মাধ্যমে সঠিক ক্রেতাদের কাছে পৌঁছান।`;

  return (
    <section className="relative pt-24 sm:pt-32 pb-16 sm:pb-24 overflow-hidden bg-[#faf9f6]">
      {/* Decorative background grid and blurs */}
      <div className="absolute inset-0 bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] [background-size:24px_24px] opacity-40" />
      <div className="absolute -top-40 right-0 w-96 h-96 bg-blue-100 rounded-full blur-3xl opacity-30 pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-80 h-80 bg-slate-200 rounded-full blur-3xl opacity-20 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Text & Content */}
          <div className="lg:col-span-7 flex flex-col justify-center text-center lg:text-left">
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 self-center lg:self-start px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-200/50 text-blue-700 text-xs sm:text-sm font-semibold mb-6"
            >
              <Flame className="w-4 h-4 fill-blue-500 text-blue-500 animate-pulse" />
              <span>
                {lang === "en" ? "4 Years of Marketing Mastery" : "৪ বছরের সফল ডিজিটাল মার্কেটিং অভিজ্ঞতা"}
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="font-display font-extrabold text-3xl sm:text-4xl md:text-5xl lg:text-5xl xl:text-6xl text-slate-900 tracking-tight leading-[1.1] mb-6"
            >
              {lang === "en" ? headlineEn : headlineBn}
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-slate-600 text-base sm:text-lg md:text-xl font-normal leading-relaxed mb-8 max-w-2xl mx-auto lg:mx-0"
            >
              {lang === "en" ? subEn : subBn}
            </motion.p>

            {/* CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 mb-10"
            >
              <a
                href="#services"
                className="w-full sm:w-auto text-center inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full bg-slate-900 hover:bg-slate-800 text-white font-bold text-base transition-all duration-300 shadow-md shadow-slate-950/10 group"
              >
                <span>{lang === "en" ? "Explore Our Services" : "সার্ভিস সমূহ দেখুন"}</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>

              <a
                href={whatsappGeneral}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto text-center inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-base transition-all duration-300 shadow-md shadow-emerald-500/10 group"
              >
                <MessageSquare className="w-4 h-4 fill-white" />
                <span>{lang === "en" ? "Order Custom Campaign" : "বিজ্ঞাপন ও বুস্টিং অর্ডার করুন"}</span>
              </a>
            </motion.div>

            {/* Key Trust Stats (Buyers will get) */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="grid grid-cols-3 gap-4 border-t border-slate-200/80 pt-8 max-w-lg mx-auto lg:mx-0 text-left"
            >
              <div>
                <span className="block font-display font-extrabold text-xl sm:text-2xl text-slate-900">
                  {lang === "en" ? "4+ Years" : "৪+ বছর"}
                </span>
                <span className="block text-[11px] sm:text-xs font-semibold uppercase text-slate-500 tracking-wider">
                  {lang === "en" ? "Expertise" : "অভিজ্ঞতা"}
                </span>
              </div>
              <div className="border-l border-slate-200 pl-4">
                <span className="block font-display font-extrabold text-xl sm:text-2xl text-slate-900">
                  {lang === "en" ? "100%" : "১০০%"}
                </span>
                <span className="block text-[11px] sm:text-xs font-semibold uppercase text-slate-500 tracking-wider">
                  {lang === "en" ? "On-Time Delivery" : "সহজ ও সঠিক ডেলিভারি"}
                </span>
              </div>
              <div className="border-l border-slate-200 pl-4">
                <span className="block font-display font-extrabold text-xl sm:text-2xl text-slate-900">
                  {lang === "en" ? "24/7" : "২৪/৭"}
                </span>
                <span className="block text-[11px] sm:text-xs font-semibold uppercase text-slate-500 tracking-wider">
                  {lang === "en" ? "Live Support" : "সরাসরি সাপোর্ট"}
                </span>
              </div>
            </motion.div>
          </div>

          {/* Right Column: Visual Interactive Image Slider & Badge Display */}
          <div className="lg:col-span-5 relative w-full flex justify-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.7 }}
              className="w-full max-w-md relative"
            >
              {/* Main Image Slider with Rounded corners - nested borders rule followed */}
              <div className="relative aspect-[4/3] rounded-2xl overflow-hidden bg-slate-100 shadow-xl border border-slate-200/60 z-10">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentSlide}
                    initial={{ opacity: 0, scale: 1.05 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.5 }}
                    className="absolute inset-0"
                  >
                    <img
                      src={slides[currentSlide].url}
                      alt={slides[currentSlide].titleEn}
                      className="w-full h-full object-contain p-3 bg-slate-900"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/10 to-transparent" />
                    
                    {/* Caption Overlay */}
                    <div className="absolute bottom-0 left-0 right-0 p-5 text-white">
                      <span className="inline-block text-[10px] font-bold tracking-widest uppercase bg-[#1877F2]/90 text-white px-2.5 py-0.5 rounded-full mb-2">
                        {lang === "en" ? "Our Core Focus" : "মূল ফোকাস"}
                      </span>
                      <h3 className="font-display font-bold text-base sm:text-lg mb-1 leading-snug">
                        {lang === "en" ? slides[currentSlide].titleEn : slides[currentSlide].titleBn}
                      </h3>
                      <p className="text-slate-300 text-xs line-clamp-2">
                        {lang === "en" ? slides[currentSlide].descEn : slides[currentSlide].descBn}
                      </p>
                    </div>
                  </motion.div>
                </AnimatePresence>
              </div>

              {/* Slider Dots */}
              <div className="flex justify-center gap-2 mt-4 relative z-20">
                {slides.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`h-2 rounded-full transition-all duration-300 ${
                      currentSlide === index ? "w-6 bg-slate-900" : "w-2 bg-slate-300 hover:bg-slate-400"
                    }`}
                    aria-label={`Go to slide ${index + 1}`}
                  />
                ))}
              </div>

              {/* Floating Professional Badges */}
              <motion.div
                animate={{ y: [0, -6, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -top-6 -left-6 z-20 bg-[#faf9f6] p-3 rounded-xl border border-slate-200/80 shadow-md flex items-center gap-2.5 max-w-[170px]"
              >
                <div className="p-2 rounded-lg bg-emerald-100 text-emerald-600">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <span className="block text-xs font-bold text-slate-900 leading-tight">
                    {lang === "en" ? "Top Certified" : "সার্টিফাইড"}
                  </span>
                  <span className="block text-[10px] text-slate-500 font-medium">
                    {lang === "en" ? "Ads Expert" : "ফেসবুক বিজ্ঞাপনী"}
                  </span>
                </div>
              </motion.div>

              <motion.div
                animate={{ y: [0, 6, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                className="absolute -bottom-2 -right-6 z-20 bg-[#faf9f6] p-3 rounded-xl border border-slate-200/80 shadow-md flex items-center gap-2.5 max-w-[180px]"
              >
                <div className="p-2 rounded-lg bg-blue-100 text-blue-600">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <span className="block text-xs font-bold text-slate-900 leading-tight">
                    {lang === "en" ? "Best Work" : "সেরা কাজ"}
                  </span>
                  <span className="block text-[10px] text-slate-500 font-medium">
                    {lang === "en" ? "Always Guaranteed" : "১০০% গ্যারান্টি"}
                  </span>
                </div>
              </motion.div>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
}
