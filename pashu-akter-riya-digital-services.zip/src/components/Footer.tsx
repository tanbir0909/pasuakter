import React, { useState } from "react";
import { motion } from "motion/react";
import { 
  MessageSquare, Send, Award, Clock, Headphones, Zap, 
  ArrowUpRight, Heart, ShieldCheck 
} from "lucide-react";
import { submitLeadQuery } from "../lib/store";

const logo = "https://i.ibb.co.com/cSnfRjFJ/IMG-20260815-135937.jpg";

interface FooterProps {
  lang: "bn" | "en";
  whatsappGeneral: string;
  logoUrl?: string;
  siteName?: string;
  onLogoClick?: () => void;
}

export default function Footer({ 
  lang, 
  whatsappGeneral, 
  logoUrl = logo, 
  siteName = "Pashu Akter Riya", 
  onLogoClick 
}: FooterProps) {
  const [clientName, setClientName] = useState("");
  const [businessNiche, setBusinessNiche] = useState("");
  const [customMessage, setCustomMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSendQuery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName.trim()) return;

    setIsSubmitting(true);
    // 1. Submit lead details to Firestore
    await submitLeadQuery(clientName, businessNiche, customMessage);

    // 2. Draft messages for WhatsApp and open redirection
    const bnMsg = `আসসালামু আলাইকুম রিয়া আপু, আমি আপনার ওয়েবসাইটের কন্টাক্ট ফরম পূরণ করেছি।\nআমার নাম: ${clientName}\nআমার ব্যবসার ধরণ: ${businessNiche || "উল্লেখ নেই"}\nআমার মেসেজ: ${customMessage || "আমি আমার ফেসবুক বুস্টিং এবং ক্যাম্পেইন সম্পর্কে আলোচনা করতে চাই।"}`;
    const enMsg = `Hello Riya, I filled your website contact form.\nMy Name: ${clientName}\nBusiness Type: ${businessNiche || "N/A"}\nMessage: ${customMessage || "I would like to discuss Facebook Ads and campaign boost opportunities."}`;

    const finalMsg = lang === "en" ? encodeURIComponent(enMsg) : encodeURIComponent(bnMsg);
    
    // Clear the form fields
    setClientName("");
    setBusinessNiche("");
    setCustomMessage("");
    setIsSubmitting(false);

    window.open(`https://wa.me/8801965338660?text=${finalMsg}`, "_blank", "noopener,noreferrer");
  };

  return (
    <footer className="bg-slate-950 text-slate-300 pt-20 pb-8 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:24px_24px] opacity-[0.03] pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 pb-16 border-b border-slate-800">
          
          {/* Column 1: Brand details & Philosophy (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div 
              onClick={() => onLogoClick && onLogoClick()} 
              className={`flex items-center gap-3 ${onLogoClick ? "cursor-pointer group" : ""}`}
            >
              <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-blue-500 transition-colors duration-300 group-hover:border-blue-400">
                <img
                  src={logoUrl}
                  alt={`${siteName} Footer Logo`}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <span className="font-display font-black text-xl text-[#faf9f6] tracking-tight block transition-colors duration-300 group-hover:text-blue-400">
                  {siteName}
                </span>
                <span className="text-[10px] font-bold text-blue-500 tracking-wider uppercase block">
                  {lang === "en" ? "Facebook Digital Marketing Specialist" : "ফেসবুক ডিজিটাল মার্কেটিং স্পেশালিস্ট"}
                </span>
              </div>
            </div>

            <p className="text-slate-400 text-xs sm:text-sm leading-relaxed max-w-md">
              {lang === "en"
                ? "We provide elite-tier Facebook advertising, professional page setup configurations, pixel setups, and organic follow growth tactics driven by over 4 years of hands-on results."
                : "আমরা ৪ বছরের বেশি সময় ধরে সফলভাবে ফেসবুক অ্যাডভার্টাইজিং, পেজ প্রফেশনাল সেটআপ, পিক্সেল ট্র্যাকিং এবং পেজ অরগানিক গ্রোথ সার্ভিস বিশ্বস্ততার সাথে প্রদান করে আসছি।"}
            </p>

            {/* Core Badges Row */}
            <div className="grid grid-cols-3 gap-3 max-w-sm pt-2">
              <div className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-3 text-center">
                <span className="block font-display font-extrabold text-blue-400 text-lg sm:text-xl">
                  {lang === "en" ? "4+ Yrs" : "৪+ বছর"}
                </span>
                <span className="block text-[10px] text-slate-500 font-bold uppercase tracking-wider">{lang === "en" ? "Experience" : "অভিজ্ঞতা"}</span>
              </div>
              <div className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-3 text-center">
                <span className="block font-display font-extrabold text-emerald-400 text-lg sm:text-xl">
                  {lang === "en" ? "100%" : "১০০%"}
                </span>
                <span className="block text-[10px] text-slate-500 font-bold uppercase tracking-wider">{lang === "en" ? "On Time" : "ডেলিভারি"}</span>
              </div>
              <div className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-3 text-center">
                <span className="block font-display font-extrabold text-amber-400 text-lg sm:text-xl">
                  {lang === "en" ? "24/7" : "২৪/৭"}
                </span>
                <span className="block text-[10px] text-slate-500 font-bold uppercase tracking-wider">{lang === "en" ? "Support" : "লাইভ চ্যাট"}</span>
              </div>
            </div>
          </div>

          {/* Column 2: Quick Links (3 cols) */}
          <div className="lg:col-span-3 space-y-6">
            <h3 className="text-sm font-bold text-[#faf9f6] tracking-wider uppercase">
              {lang === "en" ? "Quick Directory" : "সরাসরি লিঙ্ক সমূহ"}
            </h3>
            <ul className="space-y-3.5 text-xs sm:text-sm">
              <li>
                <a href="#services" className="hover:text-blue-400 transition-colors inline-flex items-center gap-1">
                  <span>{lang === "en" ? "Facebook Ads Services" : "ফেসবুক বিজ্ঞাপন সার্ভিস"}</span>
                  <ArrowUpRight className="w-3.5 h-3.5 opacity-60" />
                </a>
              </li>
              <li>
                <a href="#experience" className="hover:text-blue-400 transition-colors inline-flex items-center gap-1">
                  <span>{lang === "en" ? "Experience & Success" : "অভিজ্ঞতা ও সফলতা"}</span>
                  <ArrowUpRight className="w-3.5 h-3.5 opacity-60" />
                </a>
              </li>
              <li>
                <a href="#benefits" className="hover:text-blue-400 transition-colors inline-flex items-center gap-1">
                  <span>{lang === "en" ? "Guarantees & Support" : "গ্রাহক সেবা ও গ্যারান্টি"}</span>
                  <ArrowUpRight className="w-3.5 h-3.5 opacity-60" />
                </a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-blue-400 transition-colors inline-flex items-center gap-1">
                  <span>{lang === "en" ? "Portfolio Success Gallery" : "কাজের পোর্টফোলিও গ্যালারি"}</span>
                  <ArrowUpRight className="w-3.5 h-3.5 opacity-60" />
                </a>
              </li>
            </ul>
          </div>

          {/* Column 3: Interactive Consult Form (4 cols) */}
          <div className="lg:col-span-4 bg-white/[0.02] border border-white/[0.05] rounded-2xl p-6 sm:p-8 space-y-4">
            <h3 className="text-sm font-extrabold text-[#faf9f6] uppercase tracking-wider">
              {lang === "en" ? "Direct Consultation Form" : "সরাসরি ফ্রি পরামর্শ ফরম"}
            </h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              {lang === "en"
                ? "Enter your details below to directly build a pre-composed message and speak with Riya on WhatsApp."
                : "আপনার তথ্য দিয়ে সাবমিট বাটনে চাপ দিন, সম্পূর্ণ রেডিমেড মেসেজ সহ সরাসরি রিয়ার সাথে কথা বলুন।"}
            </p>
            <form onSubmit={handleSendQuery} className="space-y-3">
              <input
                type="text"
                required
                placeholder={lang === "en" ? "Your Name" : "আপনার নাম *"}
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-xs sm:text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
              />
              <input
                type="text"
                placeholder={lang === "en" ? "Your Niche (e.g. E-commerce)" : "ব্যবসার ক্যাটাগরি (যেমন: ই-কমার্স)"}
                value={businessNiche}
                onChange={(e) => setBusinessNiche(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-xs sm:text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
              />
              <textarea
                placeholder={lang === "en" ? "Describe your goals..." : "আপনার ব্যবসার প্রচারের লক্ষ্য সংক্ষেপে লিখুন..."}
                rows={2}
                value={customMessage}
                onChange={(e) => setCustomMessage(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-xs sm:text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-colors resize-none"
              />
              <button
                type="submit"
                disabled={isSubmitting}
                className={`w-full inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-bold text-xs sm:text-sm transition-all duration-300 ${
                  isSubmitting ? "bg-slate-800 text-slate-500 cursor-not-allowed" : "bg-blue-600 hover:bg-blue-500 text-white"
                }`}
              >
                <MessageSquare className="w-4 h-4 fill-white" />
                <span>
                  {isSubmitting 
                    ? (lang === "en" ? "Sending Details..." : "তথ্য পাঠানো হচ্ছে...")
                    : (lang === "en" ? "Launch Chat on WhatsApp" : "হোয়াটসঅ্যাপে চ্যাট চালু করুন")
                  }
                </span>
              </button>
            </form>
          </div>

        </div>

        {/* Footer Bottom Row */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>
            {lang === "en" ? "© 2026 Pashu Akter Riya. All Rights Reserved." : "© ২০২৬ পশু আক্তার রিয়া। সর্বস্বত্ব সংরক্ষিত।"}
          </p>
          <div className="flex items-center gap-1">
            <span>{lang === "en" ? "Powered with" : "ভালোবাসার সাথে তৈরি"}</span>
            <Heart className="w-3 h-3 text-red-500 fill-red-500 animate-pulse" />
            <span>{lang === "en" ? "for Bengali E-commerce Businesses" : "বাঙালি ই-কমার্স ব্যবসার জন্য"}</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
