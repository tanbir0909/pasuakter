import React, { useState, useEffect } from "react";
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged, 
  User 
} from "firebase/auth";
import { 
  LayoutDashboard, 
  Settings, 
  FolderPlus, 
  Image as ImageIcon, 
  Plus, 
  Trash2, 
  LogOut, 
  Globe, 
  ChevronRight, 
  ArrowLeft, 
  Sparkles, 
  Database, 
  AlertCircle,
  Eye,
  CheckCircle2,
  MessageSquare,
  Mail,
  Calendar
} from "lucide-react";
import { auth } from "../lib/firebase";
import { 
  useLiveConfig, 
  updateSiteConfig, 
  addCategory, 
  removeCategory, 
  addPortfolioImage, 
  deletePortfolioImage, 
  seedInitialData,
  useLiveLeads,
  deleteLeadQuery,
  Category,
  PortfolioImage
} from "../lib/store";

interface AdminPanelProps {
  lang: "bn" | "en";
  onClose: () => void;
}

export default function AdminPanel({ lang, onClose }: AdminPanelProps) {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  
  // Auth Form State
  const [isRegister, setIsRegister] = useState<boolean>(false);
  const [email, setEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [authError, setAuthError] = useState<string>("");
  const [authSuccess, setAuthSuccess] = useState<string>("");

  // Live Sync Data State
  const { logoUrl, siteName, categories, images, loading: dataLoading } = useLiveConfig();
  const { leads, loading: leadsLoading } = useLiveLeads();

  // Settings Form State
  const [formLogo, setFormLogo] = useState<string>("");
  const [formName, setFormName] = useState<string>("");
  
  // New Category Form State
  const [newCatId, setNewCatId] = useState<string>("");
  const [newCatEn, setNewCatEn] = useState<string>("");
  const [newCatBn, setNewCatBn] = useState<string>("");

  // New Image Form State
  const [newImgSrc, setNewImgSrc] = useState<string>("");
  const [newImgTitleEn, setNewImgTitleEn] = useState<string>("");
  const [newImgTitleBn, setNewImgTitleBn] = useState<string>("");
  const [newImgDescEn, setNewImgDescEn] = useState<string>("");
  const [newImgDescBn, setNewImgDescBn] = useState<string>("");
  const [newImgCat, setNewImgCat] = useState<string>("");

  // Notification / Success / Error Banner State
  const [statusMsg, setStatusMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Monitor auth state
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
    });
    return unsub;
  }, []);

  // Update local forms when live configurations load
  useEffect(() => {
    if (logoUrl) setFormLogo(logoUrl);
    if (siteName) setFormName(siteName);
  }, [logoUrl, siteName]);

  const handleDeleteLead = async (id: string) => {
    if (!id) return;
    const ok = await deleteLeadQuery(id);
    if (ok) {
      setStatusMsg({
        type: "success",
        text: lang === "en" ? "Query deleted successfully" : "মেসেজটি সফলভাবে ডিলিট করা হয়েছে"
      });
    } else {
      setStatusMsg({
        type: "error",
        text: lang === "en" ? "Failed to delete query" : "মেসেজটি ডিলিট করা যায়নি"
      });
    }
  };

  // Handle Login or Registration
  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setAuthSuccess("");
    
    if (!email || !password) {
      setAuthError(lang === "en" ? "Please fill all fields" : "অনুগ্রহ করে সব তথ্য দিন");
      return;
    }

    try {
      if (isRegister) {
        await createUserWithEmailAndPassword(auth, email, password);
        setAuthSuccess(lang === "en" ? "Admin Account Registered Successfully!" : "অ্যাডমিন অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে!");
        setIsRegister(false);
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
    } catch (err: any) {
      console.error(err);
      let errMsg = err.message;
      if (err.code === "auth/user-not-found") {
        errMsg = lang === "en" ? "Admin user not found. You can switch to 'Create Admin Account' tab to register." : "এই ইমেইলে কোনো অ্যাকাউন্ট পাওয়া যায়নি। অ্যাকাউন্ট তৈরি করতে পাশের ট্যাবে ক্লিক করুন।";
      } else if (err.code === "auth/wrong-password") {
        errMsg = lang === "en" ? "Incorrect password." : "ভুল পাসওয়ার্ড দিয়েছেন।";
      } else if (err.code === "auth/weak-password") {
        errMsg = lang === "en" ? "Password must be at least 6 characters." : "পাসওয়ার্ড অবশ্যই কমপক্ষে ৬ অক্ষরের হতে হবে।";
      }
      setAuthError(errMsg);
    }
  };

  const handleSignOut = () => {
    signOut(auth);
  };

  const showStatus = (text: string, type: "success" | "error" = "success") => {
    setStatusMsg({ type, text });
    setTimeout(() => setStatusMsg(null), 5000);
  };

  // 1. Save Site Configuration
  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    const success = await updateSiteConfig(formLogo, formName);
    if (success) {
      showStatus(lang === "en" ? "Site Configuration updated successfully!" : "ওয়েবসাইট কনফিগারেশন সফলভাবে আপডেট করা হয়েছে!");
    } else {
      showStatus(lang === "en" ? "Failed to update configuration" : "আপডেট করতে ব্যর্থ হয়েছে", "error");
    }
  };

  // 2. Seed Initial Defaults helper
  const handleSeed = async () => {
    const confirm = window.confirm(
      lang === "en" 
        ? "This will load the original certifications and profit images to your database. Continue?" 
        : "এটি আপনার ডাটাবেজে আগের সমস্ত ভেরিফাইড সার্টিফিকেট এবং প্রফিট ইমেজ লোড করবে। নিশ্চিত?"
    );
    if (!confirm) return;

    const success = await seedInitialData();
    if (success) {
      showStatus(lang === "en" ? "Initial data seeded successfully!" : "প্রাথমিক ডাটা সফলভাবে সেটআপ করা হয়েছে!");
    } else {
      showStatus(lang === "en" ? "Failed to seed data" : "ডাটা সেটআপ করতে সমস্যা হয়েছে", "error");
    }
  };

  // 3. Add Custom Category
  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatId || !newCatEn || !newCatBn) {
      showStatus(lang === "en" ? "Please fill all category fields" : "সবগুলো ক্যাটাগরি ফিল্ড পূরণ করুন", "error");
      return;
    }
    const success = await addCategory(newCatId, newCatEn, newCatBn);
    if (success) {
      showStatus(lang === "en" ? `Category '${newCatEn}' added!` : `ক্যাটাগরি '${newCatBn}' যুক্ত করা হয়েছে!`);
      setNewCatId("");
      setNewCatEn("");
      setNewCatBn("");
    } else {
      showStatus(lang === "en" ? "Failed to add category" : "ক্যাটাগরি যুক্ত করতে ব্যর্থ", "error");
    }
  };

  // 4. Remove Category
  const handleRemoveCategory = async (id: string) => {
    const confirm = window.confirm(
      lang === "en"
        ? `Are you sure you want to delete category '${id}'? This will also delete ALL images in this category.`
        : `আপনি কি নিশ্চিত যে ক্যাটাগরি '${id}' ডিলিট করতে চান? এর ভেতরের সকল ছবিও ডিলিট হয়ে যাবে।`
    );
    if (!confirm) return;

    const success = await removeCategory(id);
    if (success) {
      showStatus(lang === "en" ? "Category and associated images removed" : "ক্যাটাগরি এবং এর ভেতরের ছবিগুলো মুছে ফেলা হয়েছে");
    } else {
      showStatus(lang === "en" ? "Failed to delete category" : "ক্যাটাগরি মুছতে ব্যর্থ", "error");
    }
  };

  // 5. Add Portfolio Image
  const handleAddImage = async (e: React.FormEvent) => {
    e.preventDefault();
    const catToUse = newImgCat || (categories.length > 0 ? categories[0].id : "");
    if (!newImgSrc || !newImgTitleEn || !newImgTitleBn || !catToUse) {
      showStatus(lang === "en" ? "Please provide Image URL, Category, and Titles" : "অনুগ্রহ করে ইমেজ লিংক, ক্যাটাগরি এবং টাইটেল দিন", "error");
      return;
    }

    const success = await addPortfolioImage({
      src: newImgSrc,
      titleEn: newImgTitleEn,
      titleBn: newImgTitleBn,
      descEn: newImgDescEn,
      descBn: newImgDescBn,
      category: catToUse
    });

    if (success) {
      showStatus(lang === "en" ? "Image added successfully!" : "নতুন ছবি সফলভাবে যুক্ত হয়েছে!");
      setNewImgSrc("");
      setNewImgTitleEn("");
      setNewImgTitleBn("");
      setNewImgDescEn("");
      setNewImgDescBn("");
    } else {
      showStatus(lang === "en" ? "Failed to add image" : "ছবি যুক্ত করতে ব্যর্থ", "error");
    }
  };

  // 6. Delete Portfolio Image
  const handleDeleteImage = async (id: string) => {
    const confirm = window.confirm(
      lang === "en" ? "Are you sure you want to delete this image?" : "আপনি কি এই ছবিটি মুছে ফেলতে চান?"
    );
    if (!confirm) return;

    const success = await deletePortfolioImage(id);
    if (success) {
      showStatus(lang === "en" ? "Image deleted" : "ছবিটি মুছে ফেলা হয়েছে");
    } else {
      showStatus(lang === "en" ? "Failed to delete image" : "ছবিটি মুছতে ব্যর্থ", "error");
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900 text-white">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          <span className="font-semibold text-slate-400">Loading Secure Admin Panel...</span>
        </div>
      </div>
    );
  }

  // --- LOGIN / REGISTER PAGE ---
  if (!user) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        {/* Background Decorative Blobs */}
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-900/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-indigo-900/20 rounded-full blur-3xl pointer-events-none" />
        
        <div className="sm:mx-auto sm:w-full sm:max-w-md relative z-10 text-center">
          <div className="mx-auto w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mb-6 shadow-xl shadow-blue-500/20">
            <LayoutDashboard className="w-9 h-9 text-white" />
          </div>
          <h2 className="font-display font-black text-3xl sm:text-4xl text-white tracking-tight">
            {lang === "en" ? "Riya Ads Admin Panel" : "রিয়া অ্যাডস অ্যাডমিন প্যানেল"}
          </h2>
          <p className="mt-2 text-sm text-slate-400">
            {lang === "en" ? "Authorized access only to manage app content" : "অ্যাপের সমস্ত কন্টেন্ট ও ইমেজ কন্ট্রোল করার জন্য লগইন করুন"}
          </p>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md relative z-10">
          <div className="bg-slate-900 py-8 px-4 shadow-2xl sm:rounded-3xl border border-slate-800 sm:px-10">
            
            {/* Custom Tabs */}
            <div className="flex bg-slate-950 p-1.5 rounded-2xl mb-6 border border-slate-800">
              <button
                onClick={() => { setIsRegister(false); setAuthError(""); setAuthSuccess(""); }}
                className={`flex-1 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all duration-200 cursor-pointer ${
                  !isRegister ? "bg-blue-600 text-white shadow-lg" : "text-slate-400 hover:text-white"
                }`}
              >
                {lang === "en" ? "Log In" : "লগইন করুন"}
              </button>
              <button
                onClick={() => { setIsRegister(true); setAuthError(""); setAuthSuccess(""); }}
                className={`flex-1 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all duration-200 cursor-pointer ${
                  isRegister ? "bg-blue-600 text-white shadow-lg" : "text-slate-400 hover:text-white"
                }`}
              >
                {lang === "en" ? "Create Admin" : "অ্যাডমিন তৈরি করুন"}
              </button>
            </div>

            {authError && (
              <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-4 mb-4 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                <span className="text-xs sm:text-sm text-red-200">{authError}</span>
              </div>
            )}

            {authSuccess && (
              <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-2xl p-4 mb-4 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <span className="text-xs sm:text-sm text-emerald-200">{authSuccess}</span>
              </div>
            )}

            <form className="space-y-5" onSubmit={handleAuthSubmit}>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  {lang === "en" ? "Email Address" : "ইমেইল অ্যাড্রেস"}
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@riya.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  {lang === "en" ? "Password" : "পাসওয়ার্ড"}
                </label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              <button
                type="submit"
                className="w-full flex justify-center py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {isRegister 
                  ? (lang === "en" ? "Register Admin Account" : "নতুন অ্যাকাউন্ট তৈরি করুন")
                  : (lang === "en" ? "Sign In as Admin" : "অ্যাডমিন হিসেবে প্রবেশ করুন")
                }
              </button>
            </form>

            <div className="mt-6 pt-6 border-t border-slate-800 flex justify-center">
              <button
                onClick={onClose}
                className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>{lang === "en" ? "Back to Public Website" : "মূল ওয়েবসাইটে ফিরে যান"}</span>
              </button>
            </div>

          </div>
        </div>
      </div>
    );
  }

  // --- MAIN ADMIN DASHBOARD ---
  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans pb-16">
      
      {/* Top Banner Navigation */}
      <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800/80 px-4 py-4 shadow-md">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-xl">
              <LayoutDashboard className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-display font-black text-lg sm:text-xl text-white tracking-tight">
                {lang === "en" ? "Pashu Akter Riya - Admin Panel" : "পশু আক্তার রিয়া - অ্যাডমিন প্যানেল"}
              </h1>
              <span className="text-[10px] bg-slate-800 text-blue-400 px-2 py-0.5 rounded font-mono font-bold">
                Logged in: {user.email}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={onClose}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs sm:text-sm font-bold text-white transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">{lang === "en" ? "View Live Site" : "লাইভ সাইট দেখুন"}</span>
            </button>
            
            <button
              onClick={handleSignOut}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-red-600/10 hover:bg-red-600 text-red-400 hover:text-white text-xs sm:text-sm font-bold transition-all cursor-pointer border border-red-500/20"
              title={lang === "en" ? "Sign Out" : "লগ আউট"}
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">{lang === "en" ? "Sign Out" : "লগ আউট"}</span>
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8 space-y-8">
        
        {/* Status Toast Notification */}
        {statusMsg && (
          <div className={`fixed bottom-6 right-6 z-50 rounded-2xl p-4 shadow-2xl border flex items-center gap-3 max-w-md ${
            statusMsg.type === "success" 
              ? "bg-emerald-950 border-emerald-800 text-emerald-200" 
              : "bg-red-950 border-red-800 text-red-200"
          }`}>
            {statusMsg.type === "success" ? <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" /> : <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />}
            <span className="text-xs sm:text-sm font-semibold">{statusMsg.text}</span>
          </div>
        )}

        {/* Dynamic Data Loader Bar */}
        {dataLoading && (
          <div className="bg-blue-900/10 border border-blue-500/20 rounded-2xl p-4 flex items-center gap-3">
            <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
            <span className="text-xs sm:text-sm text-slate-300">Synchronizing with live Firebase Database...</span>
          </div>
        )}

        {/* GRID LAYOUT: SITE CONFIG & CATEGORIES */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* SECTION 1: Site configuration */}
          <div className="lg:col-span-6 bg-slate-900 border border-slate-800/80 rounded-2xl p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-blue-500" />
                <h2 className="text-base sm:text-lg font-bold text-white">
                  {lang === "en" ? "Global Website Config" : "ওয়েবসাইট মূল কনফিগারেশন"}
                </h2>
              </div>
              
              {/* Seed Button helper */}
              <button
                onClick={handleSeed}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-600/10 border border-indigo-500/20 hover:bg-indigo-600 text-indigo-400 hover:text-white text-[11px] font-bold transition-all cursor-pointer"
                title="Loads standard certificates and image list to start editing instantly."
              >
                <Database className="w-3.5 h-3.5" />
                <span>{lang === "en" ? "Seed Default Content" : "ডিফল্ট কন্টেন্ট লোড করুন"}</span>
              </button>
            </div>

            <form onSubmit={handleSaveConfig} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  {lang === "en" ? "Website Identity Name" : "নাম পরিবর্তন (Name)"}
                </label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  {lang === "en" ? "Logo Link / URL" : "লোগো ইমেজ লিংক (Logo URL)"}
                </label>
                <div className="flex gap-3">
                  <input
                    type="url"
                    required
                    value={formLogo}
                    onChange={(e) => setFormLogo(e.target.value)}
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
                  />
                  {formLogo && (
                    <div className="w-12 h-12 rounded-xl overflow-hidden border border-slate-700 bg-slate-950 shrink-0">
                      <img src={formLogo} alt="Preview" className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>
              </div>

              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm transition-all cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{lang === "en" ? "Update Site Configuration" : "কনফিগারেশন আপডেট করুন"}</span>
              </button>
            </form>
          </div>

          {/* SECTION 2: Custom Category Management */}
          <div className="lg:col-span-6 bg-slate-900 border border-slate-800/80 rounded-2xl p-6 space-y-5">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-4">
              <FolderPlus className="w-5 h-5 text-blue-500" />
              <h2 className="text-base sm:text-lg font-bold text-white">
                {lang === "en" ? "Categories Manager" : "ক্যাটাগরি কন্ট্রোলার"}
              </h2>
            </div>

            {/* List existing */}
            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {categories.map((cat) => (
                <div key={cat.id} className="flex items-center justify-between bg-slate-950 border border-slate-800/60 rounded-xl p-3">
                  <div>
                    <span className="block text-xs font-bold text-blue-400 font-mono">ID: {cat.id}</span>
                    <span className="text-xs sm:text-sm font-semibold text-white">
                      {cat.nameBn} <span className="text-slate-400 font-normal">({cat.nameEn})</span>
                    </span>
                  </div>
                  <button
                    onClick={() => handleRemoveCategory(cat.id)}
                    className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-600 text-red-400 hover:text-white transition-all cursor-pointer"
                    title={lang === "en" ? "Delete Category" : "ক্যাটাগরি মুছুন"}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            {/* Add Category Form */}
            <form onSubmit={handleAddCategory} className="border-t border-slate-850 pt-4 space-y-3">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                {lang === "en" ? "Add New Category" : "নতুন ক্যাটাগরি তৈরি করুন"}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="text"
                  required
                  placeholder="ID (e.g., custom_sales)"
                  value={newCatId}
                  onChange={(e) => setNewCatId(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-blue-500 transition-colors"
                />
                <input
                  type="text"
                  required
                  placeholder="Name (English)"
                  value={newCatEn}
                  onChange={(e) => setNewCatEn(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-blue-500 transition-colors"
                />
                <input
                  type="text"
                  required
                  placeholder="নাম (বাংলা)"
                  value={newCatBn}
                  onChange={(e) => setNewCatBn(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>
              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{lang === "en" ? "Save Category" : "ক্যাটাগরি সেভ করুন"}</span>
              </button>
            </form>
          </div>
        </div>

        {/* SECTION 3: Portfolio Image Manager */}
        <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-6 space-y-6">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-4">
            <ImageIcon className="w-5 h-5 text-blue-500" />
            <h2 className="text-base sm:text-lg font-bold text-white">
              {lang === "en" ? "Portfolio Portfolio Images & Strategy Links" : "কাজের পোর্টফোলিও ইমেজ ও লিঙ্ক ম্যানেজার"}
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Form Side (5 cols) */}
            <form onSubmit={handleAddImage} className="lg:col-span-5 space-y-4">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800/50 pb-2">
                {lang === "en" ? "Upload / Link New Portfolio Image" : "নতুন ছবি বা কাজের লিংক আপলোড"}
              </h3>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  {lang === "en" ? "Paste Image Link / URL *" : "ইমেজ লিংক / ইউআরএল *"}
                </label>
                <input
                  type="url"
                  required
                  placeholder="https://i.ibb.co.com/...jpg"
                  value={newImgSrc}
                  onChange={(e) => setNewImgSrc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                    {lang === "en" ? "Select Category *" : "ক্যাটাগরি নির্বাচন করুন *"}
                  </label>
                  <select
                    value={newImgCat}
                    onChange={(e) => setNewImgCat(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
                  >
                    <option value="">-- Choose Category --</option>
                    {categories.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.nameBn} ({cat.id})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                    {lang === "en" ? "Title (English) *" : "শিরোনাম (English) *"}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="E-commerce ROI Case"
                    value={newImgTitleEn}
                    onChange={(e) => setNewImgTitleEn(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  {lang === "en" ? "Title (Bengali) *" : "শিরোনাম (বাংলা) *"}
                </label>
                <input
                  type="text"
                  required
                  placeholder="ক্যাম্পেইন রেভিনিউ ও প্রফিট রিপোর্ট"
                  value={newImgTitleBn}
                  onChange={(e) => setNewImgTitleBn(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                    {lang === "en" ? "Description (English)" : "সংক্ষিপ্ত বিবরণ (English)"}
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Detailed conversions details..."
                    value={newImgDescEn}
                    onChange={(e) => setNewImgDescEn(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-blue-500 transition-colors resize-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                    {lang === "en" ? "Description (Bengali)" : "সংক্ষিপ্ত বিবরণ (বাংলা)"}
                  </label>
                  <textarea
                    rows={2}
                    placeholder="বিজ্ঞাপন সফলভাবে পরিচালনার ডাটা..."
                    value={newImgDescBn}
                    onChange={(e) => setNewImgDescBn(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-blue-500 transition-colors resize-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm transition-all cursor-pointer shadow-lg shadow-blue-500/10"
              >
                <Plus className="w-5 h-5 text-white" />
                <span>{lang === "en" ? "Upload to Live Site" : "পোর্টফোলিওতে ছবি যুক্ত করুন"}</span>
              </button>
            </form>

            {/* List / Grid Side (7 cols) */}
            <div className="lg:col-span-7 space-y-4">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800/50 pb-2 flex justify-between items-center">
                <span>{lang === "en" ? "Active Portfolio Images" : "বর্তমানে ওয়েবসাইটে থাকা ইমেজ সমূহ"}</span>
                <span className="text-[10px] bg-slate-800 text-slate-400 px-2.5 py-0.5 rounded-full font-bold">
                  {images.length} {lang === "en" ? "Images Total" : "টি ছবি মোট"}
                </span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-[500px] overflow-y-auto pr-2">
                {images.map((img) => (
                  <div key={img.id || img.titleEn} className="bg-slate-950 border border-slate-800/80 rounded-2xl overflow-hidden flex flex-col justify-between">
                    <div className="relative aspect-video w-full overflow-hidden bg-slate-900 border-b border-slate-800">
                      <img src={img.src} alt={img.titleBn} className="w-full h-full object-cover" />
                      <span className="absolute top-2 left-2 text-[10px] bg-blue-600 text-white font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider shadow-sm">
                        {img.category}
                      </span>
                    </div>

                    <div className="p-4 space-y-2 flex-1 flex flex-col justify-between">
                      <div>
                        <h4 className="text-xs sm:text-sm font-bold text-white line-clamp-1">{img.titleBn}</h4>
                        <span className="block text-[11px] text-slate-500 line-clamp-1 italic">{img.titleEn}</span>
                      </div>

                      <div className="pt-3 border-t border-slate-850 flex items-center justify-end">
                        <button
                          onClick={() => img.id && handleDeleteImage(img.id)}
                          className="inline-flex items-center gap-1 text-[11px] font-bold text-red-400 hover:text-white bg-red-500/10 hover:bg-red-600 px-3 py-1.5 rounded-lg transition-all cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>{lang === "en" ? "Delete" : "ডিলিট করুন"}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>

        {/* SECTION 4: Client Consultation Leads */}
        <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-blue-500" />
              <h2 className="text-base sm:text-lg font-bold text-white">
                {lang === "en" ? "Client Leads & Inquiries" : "গ্রাহকের মেসেজ ও ফ্রি পরামর্শ ফর্ম লিড"}
              </h2>
            </div>
            <span className="text-xs bg-slate-850 text-blue-400 px-3 py-1 rounded-full font-bold">
              {leads.length} {lang === "en" ? "Inquiries Total" : "টি মেসেজ মোট"}
            </span>
          </div>

          {leadsLoading ? (
            <div className="py-8 text-center text-slate-500 text-xs sm:text-sm">
              <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
              <span>{lang === "en" ? "Loading client inquiries..." : "গ্রাহকের মেসেজ লোড হচ্ছে..."}</span>
            </div>
          ) : leads.length === 0 ? (
            <div className="py-12 text-center text-slate-500 border border-dashed border-slate-800/80 rounded-2xl">
              <MessageSquare className="w-8 h-8 text-slate-700 mx-auto mb-2" />
              <p className="text-xs sm:text-sm font-semibold">
                {lang === "en" ? "No consultation inquiries submitted yet." : "এখনো কোনো ফ্রি পরামর্শ বা মেসেজ সাবমিট করা হয়নি।"}
              </p>
              <p className="text-[11px] text-slate-600 mt-1">
                {lang === "en" ? "Submissions from the footer form will appear here in real-time." : "ওয়েবসাইটের ফুটারে থাকা ফর্মটি পূরণ করলে তা এখানে লাইভ দেখা যাবে।"}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {leads.map((lead) => (
                <div key={lead.id} className="bg-slate-950 border border-slate-800/60 rounded-2xl p-5 flex flex-col justify-between space-y-4 hover:border-slate-800 transition-all">
                  <div className="space-y-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="text-sm font-bold text-white">{lead.clientName}</h4>
                        {lead.businessNiche && (
                          <span className="inline-block text-[10px] text-blue-400 bg-blue-950 border border-blue-900/40 px-2 py-0.5 rounded-full font-bold mt-1 uppercase">
                            {lead.businessNiche}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 text-slate-500 text-[10px]">
                        <Calendar className="w-3 h-3 text-slate-600" />
                        <span>{new Date(lead.createdAt).toLocaleDateString(lang === "bn" ? "bn-BD" : "en-US", {
                          month: "short",
                          day: "numeric",
                          hour: "2-digit",
                          minute: "2-digit"
                        })}</span>
                      </div>
                    </div>

                    <p className="text-slate-300 text-xs sm:text-sm leading-relaxed bg-slate-900/50 p-3 rounded-xl border border-slate-850 whitespace-pre-wrap">
                      {lead.customMessage || (lang === "en" ? "No message text provided." : "কোনো মেসেজ প্রদান করা হয়নি।")}
                    </p>
                  </div>

                  <div className="flex justify-end pt-2 border-t border-slate-900">
                    <button
                      onClick={() => lead.id && handleDeleteLead(lead.id)}
                      className="inline-flex items-center gap-1 text-[11px] font-bold text-red-400 hover:text-white bg-red-500/10 hover:bg-red-600 px-3 py-1.5 rounded-lg transition-all cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{lang === "en" ? "Delete Inquiry" : "মেসেজ মুছুন"}</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
