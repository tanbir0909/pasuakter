import { motion } from "motion/react";
import { Award, ShieldCheck, CheckCircle2, ThumbsUp, Calendar, Zap, MessageSquare } from "lucide-react";
import { formatNumber } from "../utils/localization";

interface ExperienceProps {
  lang: "bn" | "en";
  whatsappGeneral: string;
}

export default function Experience({ lang, whatsappGeneral }: ExperienceProps) {
  const experiences = [
    {
      icon: <Calendar className="w-6 h-6 text-blue-600" />,
      titleEn: "Experience 4 Years",
      titleBn: "৪ বছরের সফল অভিজ্ঞতা",
      descEn: "Deep expertise in setting up highly profitable Facebook ad campaigns and optimizing standard ad accounts for high ROI.",
      descBn: "উচ্চ মুনাফাদায়ক ফেসবুক বিজ্ঞাপন সেটআপ এবং কম খরচে সর্বোচ্চ বিক্রির লক্ষ্যে অ্যাড অ্যাকাউন্ট অপ্টিমাইজেশনের দীর্ঘ অভিজ্ঞতা।",
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-emerald-600" />,
      titleEn: "Professional Service",
      titleBn: "পেশাদার সেবা ও নিয়মানুবর্তিতা",
      descEn: "Premium campaigns crafted with deep target market research, tailored audience interest mapping, and professional configurations.",
      descBn: "সঠিক কাস্টমারদের টার্গেট করে গভীর গবেষণার মাধ্যমে প্রফেশনাল ফেসবুক ক্যাম্পেইন পরিচালনা করা হয়।",
    },
    {
      icon: <ThumbsUp className="w-6 h-6 text-amber-600" />,
      titleEn: "Best Work Provided",
      titleBn: "সেরা কাজের নিশ্চয়তা",
      descEn: "We focus heavily on the quality and engagement of your posts to guarantee conversion and customer satisfaction.",
      descBn: "আপনার ব্র্যান্ডের প্রচারণা নিশ্চিত করতে প্রতিটি বিজ্ঞাপনের ডিজাইন এবং কপিরাইটিংয়ে সেরা মান প্রদান করি।",
    },
  ];

  return (
    <section id="experience" className="py-20 bg-slate-50 border-y border-slate-200/50 relative overflow-hidden">
      {/* Background soft grids */}
      <div className="absolute top-0 right-1/4 w-80 h-80 bg-blue-50 rounded-full blur-3xl opacity-60 pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-72 h-72 bg-indigo-50 rounded-full blur-3xl opacity-60 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Stats Cards & Accolades */}
          <div className="lg:col-span-5 order-2 lg:order-1">
            <div className="grid grid-cols-2 gap-4">
              
              {/* Experience Card */}
              <motion.div
                whileHover={{ y: -4 }}
                transition={{ duration: 0.3 }}
                className="bg-[#faf9f6] p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between"
              >
                <div className="p-3 rounded-xl bg-blue-100/60 text-blue-600 w-fit mb-4">
                  <Award className="w-6 h-6" />
                </div>
                <div>
                  <span className="block font-display font-extrabold text-4xl text-slate-900 leading-none mb-1">
                    {formatNumber("4+", lang)}
                  </span>
                  <span className="block text-xs font-bold text-slate-500 uppercase tracking-wider leading-snug">
                    {lang === "en" ? "Years Experience" : "বছরের অভিজ্ঞতা"}
                  </span>
                </div>
              </motion.div>

              {/* Work Delivery Success */}
              <motion.div
                whileHover={{ y: -4 }}
                transition={{ duration: 0.3 }}
                className="bg-[#faf9f6] p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between"
              >
                <div className="p-3 rounded-xl bg-emerald-100/60 text-emerald-600 w-fit mb-4">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div>
                  <span className="block font-display font-extrabold text-4xl text-slate-900 leading-none mb-1">
                    {formatNumber("100%", lang)}
                  </span>
                  <span className="block text-xs font-bold text-slate-500 uppercase tracking-wider leading-snug">
                    {lang === "en" ? "On-Time Done" : "সঠিক সময়ে ডেলিভারি"}
                  </span>
                </div>
              </motion.div>

              {/* Total Setup Services */}
              <motion.div
                whileHover={{ y: -4 }}
                transition={{ duration: 0.3 }}
                className="bg-[#faf9f6] p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between col-span-2"
              >
                <div className="flex items-center gap-4">
                  <div className="p-3 rounded-xl bg-indigo-100/60 text-indigo-600 w-fit">
                    <Zap className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="block text-lg font-bold text-slate-900">
                      {lang === "en" ? "Premium Marketing Provided" : "পেশাদার ফেসবুক সার্ভিস"}
                    </span>
                    <span className="text-xs font-semibold text-indigo-600">
                      {lang === "en" ? "Facebook Ads, Campaigns & Page Setup" : "ফেসবুক বিজ্ঞাপন, ক্যাম্পেইন ও পেজ সেটআপ"}
                    </span>
                  </div>
                </div>
              </motion.div>

            </div>
          </div>

          {/* Right Column: Detailed Narrative Content */}
          <div className="lg:col-span-7 order-1 lg:order-2">
            <span className="text-xs font-extrabold text-blue-600 tracking-widest uppercase block mb-3">
              {lang === "en" ? "EXPERIENCE & PHILOSOPHY" : "অভিজ্ঞতা ও কাজের ধরন"}
            </span>
            <h2 className="font-display font-bold text-3xl sm:text-4xl text-slate-900 mb-6 leading-tight">
              {lang === "en" 
                ? "We Provide High-Quality Digital Marketing Services Built to Convert" 
                : "আমরা নিখুঁত ও উচ্চ মানসম্পন্ন ডিজিটাল মার্কেটিং সার্ভিস প্রদান করি"}
            </h2>
            <p className="text-slate-600 text-sm sm:text-base leading-relaxed mb-8">
              {lang === "en"
                ? "As an experienced Facebook advertiser, Pashu Akter Riya ensures your business is set up properly on the world's largest social media platform. We do not just run ads—we build complete high-converting visual systems, fix technical issues in ad managers, and build targeted buyer personas to unlock massive sales opportunities."
                : "পশু আক্তার রিয়ার সাথে আপনি শুধুমাত্র বিজ্ঞাপন পরিচালনা করবেন না, বরং আপনার ব্যবসার পুরো ব্র্যান্ডিং ও সেটআপকে বদলে ফেলবেন। আমরা ফেসবুক অ্যাড অ্যাকাউন্ট সেটআপ, নিখুঁত পেজ কাস্টমাইজেশন, অডিয়েন্স রিসার্চ এবং ডাটা-চালিত ক্যাম্পেইনের মাধ্যমে সঠিক কাস্টমারকে আকর্ষণ করি।"
              }
            </p>

            {/* Structured points */}
            <div className="space-y-6">
              {experiences.map((exp, index) => (
                <div key={index} className="flex gap-4">
                  <div className="flex-shrink-0 mt-1">
                    <div className="p-2.5 rounded-xl bg-[#faf9f6] border border-slate-200 shadow-sm">
                      {exp.icon}
                    </div>
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-base sm:text-lg mb-1">
                      {lang === "en" ? exp.titleEn : exp.titleBn}
                    </h3>
                    <p className="text-slate-500 text-xs sm:text-sm leading-relaxed">
                      {lang === "en" ? exp.descEn : exp.descBn}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 pt-4">
              <a
                href={whatsappGeneral}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm transition-all duration-300"
              >
                <span>{lang === "en" ? "Request a Free Business Consultation" : "ফ্রি বিজনেস পরামর্শের জন্য মেসেজ দিন"}</span>
                <MessageSquare className="w-4 h-4 fill-white" />
              </a>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
}
