import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Maximize2, X, Image as ImageIcon } from "lucide-react";
import { useLiveConfig } from "../lib/store";

interface ImageGalleryProps {
  lang: "bn" | "en";
}

export default function ImageGallery({ lang }: ImageGalleryProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const { categories, images, loading } = useLiveConfig();
  const [activeTab, setActiveTab] = useState<string>("all");

  const filteredImages = activeTab === "all"
    ? images
    : images.filter(img => img.category === activeTab);

  return (
    <section id="gallery" className="py-24 bg-white relative">
      {/* Decorative gradients */}
      <div className="absolute top-0 left-1/4 w-80 h-80 bg-slate-50 rounded-full blur-3xl opacity-60 pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-blue-50/50 rounded-full blur-3xl opacity-40 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 text-slate-800 text-xs font-bold uppercase mb-4 border border-slate-200/50"
          >
            <ImageIcon className="w-3.5 h-3.5 text-[#1877F2]" />
            <span>{lang === "en" ? "My Success Portfolio" : "আমাদের কাজের প্রমাণ ও গ্যালারি"}</span>
          </motion.div>
          
          <h2 className="font-display font-bold text-3xl sm:text-4xl md:text-5xl text-slate-900 tracking-tight leading-tight mb-4">
            {lang === "en" 
              ? "Verified Credentials & Ad Profits" 
              : "সার্টিফিকেশন ও ক্যাম্পেইন প্রফিট"}
          </h2>
          
          <p className="text-slate-600 text-sm sm:text-base md:text-lg">
            {lang === "en"
              ? "Take a closer look at our official credentials and advanced ad strategies designed to run successful, highly profitable meta operations."
              : "আমরা যেই আন্তর্জাতিক সার্টিফিকেশন এবং প্রফিটেবল ফর্মুলার মাধ্যমে ক্লায়েন্টদের সফল ক্যাম্পেইন পরিচালনা করি তার ভেরিফাইড বিবরণ ও সেলস রিপোর্ট দেখে নিন।"}
          </p>
        </div>

        {/* Dynamic Category Filter Tabs */}
        <div className="flex flex-wrap justify-center items-center gap-2 sm:gap-3 mb-12">
          <button
            onClick={() => setActiveTab("all")}
            className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-bold transition-all duration-300 border cursor-pointer ${
              activeTab === "all"
                ? "bg-[#1877F2] text-white border-[#1877F2] shadow-md shadow-blue-500/10"
                : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100"
            }`}
          >
            {lang === "en" ? "All Highlights" : "সবগুলো ছবি"}
          </button>
          {categories.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-bold transition-all duration-300 border cursor-pointer ${
                activeTab === tab.id
                  ? "bg-[#1877F2] text-white border-[#1877F2] shadow-md shadow-blue-500/10"
                  : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100"
              }`}
            >
              {lang === "en" ? tab.nameEn : tab.nameBn}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-12 gap-3">
            <div className="w-8 h-8 border-2 border-[#1877F2] border-t-transparent rounded-full animate-spin"></div>
            <span className="text-sm text-slate-500">Loading dynamic gallery...</span>
          </div>
        ) : (
          /* Gallery Grid */
          <motion.div 
            layout
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            <AnimatePresence mode="popLayout">
              {filteredImages.map((img) => {
                const matchedCat = categories.find((c) => c.id === img.category);
                const catLabel = lang === "en" 
                  ? (matchedCat ? matchedCat.nameEn : "Certification") 
                  : (matchedCat ? matchedCat.nameBn : "সার্টিফিকেশন");

                return (
                  <motion.div
                    key={img.id || img.titleEn}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ duration: 0.4 }}
                    className="group relative flex flex-col justify-between bg-slate-50 rounded-2xl overflow-hidden border border-slate-200/80 shadow-sm hover:shadow-lg hover:border-blue-200 transition-all duration-300"
                  >
                    {/* Image Frame */}
                    <div className="relative aspect-[4/3] overflow-hidden bg-slate-50 border-b border-slate-200/50 flex items-center justify-center p-3">
                      <img
                        src={img.src}
                        alt={img.titleEn}
                        className="w-full h-full object-contain group-hover:scale-102 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-slate-950/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                        <button
                          onClick={() => setSelectedImage(img.src)}
                          className="p-3 rounded-full bg-white/90 text-slate-800 hover:bg-white shadow-md hover:scale-110 transition-all duration-200 cursor-pointer"
                          aria-label="Maximize image"
                        >
                          <Maximize2 className="w-5 h-5" />
                        </button>
                      </div>
                      <span className="absolute bottom-3 left-3 text-[10px] font-bold text-white bg-slate-900/80 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10">
                        {catLabel}
                      </span>
                    </div>

                    {/* Text Info */}
                    <div className="p-6 bg-slate-50">
                      <h3 className="font-display font-extrabold text-slate-900 text-base sm:text-lg mb-2 leading-snug group-hover:text-[#1877F2] transition-colors">
                        {lang === "en" ? img.titleEn : img.titleBn}
                      </h3>
                      {img.descEn || img.descBn ? (
                        <p className="text-slate-500 text-xs sm:text-sm leading-relaxed">
                          {lang === "en" ? img.descEn : img.descBn}
                        </p>
                      ) : null}
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </motion.div>
        )}

        {/* Modal Full Screen Popup */}
        <AnimatePresence>
          {selectedImage && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-sm flex items-center justify-center p-4"
              onClick={() => setSelectedImage(null)}
            >
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute top-4 right-4 p-3 rounded-full bg-white/10 text-white hover:bg-white/20 transition-all cursor-pointer"
                aria-label="Close preview"
              >
                <X className="w-6 h-6" />
              </button>
              
              <motion.div
                initial={{ scale: 0.95 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0.95 }}
                className="relative max-w-4xl max-h-[85vh] w-full h-full overflow-hidden rounded-2xl flex items-center justify-center bg-slate-900/40 p-2"
                onClick={(e) => e.stopPropagation()}
              >
                <img
                  src={selectedImage}
                  alt="Portfolio Fullscreen"
                  className="max-w-full max-h-[80vh] object-contain rounded-lg shadow-2xl"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
