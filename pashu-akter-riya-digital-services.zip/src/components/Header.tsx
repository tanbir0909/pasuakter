import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MessageSquare, Menu, X, ArrowRight, ShieldCheck, Globe } from "lucide-react";

const logo = "https://i.ibb.co.com/cSnfRjFJ/IMG-20260815-135937.jpg";

interface HeaderProps {
  lang: "bn" | "en";
  setLang: (lang: "bn" | "en") => void;
  whatsappGeneral: string;
  logoUrl?: string;
  siteName?: string;
  onLogoClick?: () => void;
}

export default function Header({ 
  lang, 
  setLang, 
  whatsappGeneral, 
  logoUrl = logo, 
  siteName = "Pashu Akter Riya", 
  onLogoClick 
}: HeaderProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const menuItems = [
    { nameEn: "Services", nameBn: "সার্ভিস সমূহ", href: "#services" },
    { nameEn: "Experience", nameBn: "অভিজ্ঞতা", href: "#experience" },
    { nameEn: "Why Choose Me", nameBn: "কেন আমাকে নিবেন", href: "#benefits" },
    { nameEn: "Gallery", nameBn: "গ্যালারি", href: "#gallery" },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[#faf9f6]/95 backdrop-blur-md border-b border-slate-200/50 shadow-sm py-3"
          : "bg-transparent py-5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo and Name */}
          <a 
            href="#" 
            onClick={(e) => {
              if (onLogoClick) {
                e.preventDefault();
                onLogoClick();
              }
            }} 
            className="flex items-center gap-3 group"
          >
            <div className="relative w-12 h-12 rounded-full overflow-hidden border-2 border-blue-600/30 group-hover:border-blue-600 transition-colors duration-300">
              <img
                src={logoUrl}
                alt={`${siteName} Logo`}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-blue-600/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </div>
            <div>
              <span className="font-display font-extrabold text-lg sm:text-xl text-slate-900 tracking-tight block">
                {siteName}
              </span>
              <span className="text-[11px] font-semibold text-blue-600 tracking-wider uppercase block">
                {lang === "en" ? "Facebook Ads Specialist" : "ফেসবুক অ্যাডস স্পেশালিস্ট"}
              </span>
            </div>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            {menuItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="font-medium text-sm text-slate-600 hover:text-blue-600 transition-colors duration-200 relative py-1 after:absolute after:bottom-0 after:left-0 after:right-0 after:h-[2px] after:bg-blue-600 after:scale-x-0 hover:after:scale-x-100 after:transition-transform after:duration-300"
              >
                {lang === "en" ? item.nameEn : item.nameBn}
              </a>
            ))}
          </nav>

          {/* Controls: Language and CTA */}
          <div className="hidden sm:flex items-center gap-4">
            {/* Language Toggle Button */}
            <button
              onClick={() => setLang(lang === "en" ? "bn" : "en")}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 hover:bg-slate-200/80 text-xs font-semibold text-slate-700 transition-all duration-200 border border-slate-200/40"
              aria-label="Toggle language"
            >
              <Globe className="w-3.5 h-3.5 text-slate-500" />
              <span>{lang === "en" ? "বাংলা" : "English"}</span>
            </button>

            {/* General WhatsApp Button */}
            <a
              href={whatsappGeneral}
              target="_blank"
              rel="noopener noreferrer"
              className="relative inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#1877F2] hover:bg-blue-700 text-white font-semibold text-sm transition-all duration-300 hover:shadow-lg hover:shadow-blue-600/20 group"
            >
              <MessageSquare className="w-4 h-4 fill-white" />
              <span>{lang === "en" ? "Let's Talk" : "যোগাযোগ করুন"}</span>
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
            </a>
          </div>

          {/* Mobile Actions and Hamburger */}
          <div className="flex items-center gap-3 lg:hidden">
            {/* Language Toggle */}
            <button
              onClick={() => setLang(lang === "en" ? "bn" : "en")}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-full bg-slate-100 text-xs font-bold text-slate-700 border border-slate-200/40"
            >
              <Globe className="w-3.5 h-3.5 text-slate-500" />
              <span>{lang === "en" ? "বাং" : "EN"}</span>
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200/80 text-slate-800 transition-all duration-200"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="lg:hidden bg-[#faf9f6] border-b border-slate-200 shadow-xl overflow-hidden"
          >
            <div className="px-4 pt-3 pb-6 space-y-3">
              {menuItems.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="block px-4 py-3 rounded-xl font-semibold text-slate-700 hover:bg-blue-50 hover:text-blue-600 transition-all duration-200 text-base"
                >
                  {lang === "en" ? item.nameEn : item.nameBn}
                </a>
              ))}
              <div className="pt-4 border-t border-slate-200/60 px-4">
                <a
                  href={whatsappGeneral}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setMobileMenuOpen(false)}
                  className="w-full justify-center inline-flex items-center gap-2.5 px-6 py-3.5 rounded-xl bg-[#1877F2] text-white font-bold text-base transition-all duration-300"
                >
                  <MessageSquare className="w-5 h-5 fill-white" />
                  <span>{lang === "en" ? "Let's Talk on WhatsApp" : "হোয়াটসঅ্যাপে কথা বলুন"}</span>
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
