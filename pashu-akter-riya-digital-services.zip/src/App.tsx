import { useState } from "react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import Experience from "./components/Experience";
import Services from "./components/Services";
import BuyersBenefits from "./components/BuyersBenefits";
import ImageGallery from "./components/ImageGallery";
import WorkProof from "./components/WorkProof";
import Footer from "./components/Footer";
import AdminPanel from "./components/AdminPanel";
import { useLiveConfig } from "./lib/store";
import { MessageSquare } from "lucide-react";

export default function App() {
  const [lang, setLang] = useState<"bn" | "en">("bn");
  const [view, setView] = useState<"home" | "admin">("home");

  const { logoUrl, siteName } = useLiveConfig();

  const whatsappGeneral = "https://wa.me/8801965338660?text=%20%20%20%E0%A6%86%E0%A6%B8%E0%A6%B8%E0%A6%BE%E0%A6%B2%E0%A6%BE%E0%A6%AE%E0%A7%81%20%E0%A6%86%E0%A6%B2%E0%A6%BE%E0%A6%87%E0%A6%95%E0%A7%81%E0%A6%AE%20%E0%A6%B8%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%B0%20%0A%E0%A6%86%E0%A6%AA%E0%A6%A8%E0%A6%BE%E0%A6%B0%20%E0%A6%95%E0%A6%BF%20%E0%A6%B8%E0%A6%BE%E0%A6%B0%E0%A7%8D%E0%A6%AD%E0%A6%BF%E0%A6%B8%20%E0%A6%B2%E0%A6%BE%E0%A6%90%E0%A6%97%E0%A6%AC%E0%A7%87%20%E0%A6%86%E0%A6%AE%E0%A6%BE%E0%A6%95%E0%A7%87%20%0A%E0%A6%AE%E0%A7%87%E0%A6%B8%E0%A7%87%E0%A6%9C%20%E0%A6%95%E0%A6%B0%E0%A7%81%E0%A6%A8%E0%A5%A4%0A";

  if (view === "admin") {
    return <AdminPanel lang={lang} onClose={() => setView("home")} />;
  }

  return (
    <div className="min-h-screen bg-[#faf9f6] text-slate-800 antialiased font-sans selection:bg-blue-600/10 selection:text-blue-700">
      
      {/* 1. Header Navigation with dynamic configs and Admin panel trigger */}
      <Header 
        lang={lang} 
        setLang={setLang} 
        whatsappGeneral={whatsappGeneral} 
        logoUrl={logoUrl}
        siteName={siteName}
        onLogoClick={() => setView("admin")}
      />

      {/* 2. Hero Section */}
      <Hero lang={lang} whatsappGeneral={whatsappGeneral} siteName={siteName} />

      {/* 3. Services Catalog Grid */}
      <Services lang={lang} />

      {/* 4. Professional Experience & Agency metrics */}
      <Experience lang={lang} whatsappGeneral={whatsappGeneral} />

      {/* 5. Portfolio Showcase Gallery */}
      <ImageGallery lang={lang} />

      {/* 6. Work Proof Section */}
      <WorkProof lang={lang} />

      {/* 7. Guarantees / Buyers benefits */}
      <BuyersBenefits lang={lang} />

      {/* 8. Footer Contacts & Direct Chat triggers */}
      <Footer 
        lang={lang} 
        whatsappGeneral={whatsappGeneral} 
        logoUrl={logoUrl}
        siteName={siteName}
        onLogoClick={() => setView("admin")}
      />

      {/* Floating Dynamic Sticky WhatsApp Button */}
      <a
        href={whatsappGeneral}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 flex items-center gap-2 px-4 py-3.5 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-sm shadow-xl hover:shadow-emerald-500/20 hover:scale-105 active:scale-95 transition-all duration-300 group"
        aria-label="Direct Chat on WhatsApp"
      >
        <MessageSquare className="w-5 h-5 fill-white" />
        <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-500 ease-out whitespace-nowrap">
          {lang === "en" ? "Chat with Riya" : "রিয়ার সাথে সরাসরি কথা বলুন"}
        </span>
        <span className="flex h-2.5 w-2.5 relative">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-100"></span>
        </span>
      </a>

    </div>
  );
}
