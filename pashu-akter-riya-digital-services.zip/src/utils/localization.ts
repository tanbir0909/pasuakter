export function formatNumber(num: number | string, lang: "en" | "bn"): string {
  const numStr = String(num);
  if (lang === "en") return numStr;
  const bnDigits = ["০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯"];
  return numStr.replace(/\d/g, (d) => bnDigits[parseInt(d)]);
}
