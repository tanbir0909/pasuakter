import { useState, useEffect } from "react";
import { 
  collection, 
  doc, 
  onSnapshot, 
  setDoc, 
  addDoc, 
  deleteDoc, 
  getDocs,
  query,
  orderBy 
} from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "./firebase";

export interface Category {
  id: string;
  nameEn: string;
  nameBn: string;
}

export interface PortfolioImage {
  id?: string;
  src: string;
  titleEn: string;
  titleBn: string;
  descEn: string;
  descBn: string;
  category: string; // references Category id
  categoryEn?: string;
  categoryBn?: string;
  createdAt?: any;
}

export const defaultCategories: Category[] = [
  { id: "certifications", nameEn: "Certifications", nameBn: "সার্টিফিকেশন সমূহ" },
  { id: "my_profit", nameEn: "My Profit", nameBn: "মাই প্রফিট" }
];

export const defaultImages: PortfolioImage[] = [
  {
    src: "https://i.ibb.co.com/G4MPX0vM/IMG-20260815-152356.jpg",
    titleEn: "Meta Certified Digital Marketing Associate",
    titleBn: "মেটা সার্টিফাইড ডিজিটাল মার্কেটিং অ্যাসোসিয়েট",
    descEn: "Verified credentials confirming skills in Meta platforms, ads manager setups, and targeting fundamentals.",
    descBn: "মেটা বিজ্ঞাপনের ক্যাম্পেইন পরিচালনা এবং সঠিক কাস্টমার টার্গেটিংয়ের ওপর আন্তর্জাতিক সার্টিফিকেশন।",
    category: "certifications",
    categoryEn: "Certification & Trust",
    categoryBn: "সার্টিফিকেশন ও বিশ্বাস"
  },
  {
    src: "https://i.ibb.co.com/27jw9r1N/IMG-20260815-152342.jpg",
    titleEn: "Meta Certified Media Planning Professional",
    titleBn: "মেটা সার্টিফাইড মিডিয়া প্ল্যানিং প্রফেশনাল",
    descEn: "Advanced certification verifying competency in campaign architecture, budget optimizations, and full funnel design.",
    descBn: "মেটা মিডিয়া প্ল্যানিং প্রফেশনাল হিসেবে নিখুঁত অডিয়েন্স প্ল্যানিং এবং অপ্টিমাইজেশন যোগ্যতা।",
    category: "certifications",
    categoryEn: "Certification & Trust",
    categoryBn: "সার্টিফিকেশন ও বিশ্বাস"
  },
  {
    src: "https://i.ibb.co.com/Fq36mS8W/IMG-20260815-152332.jpg",
    titleEn: "CertiProf Digital Marketing Professional",
    titleBn: "সার্টিপ্রফ ডিজিটাল মার্কেটিং প্রফেশনাল",
    descEn: "Industry-standard certification for overall marketing execution, analytics, and ROI modeling.",
    descBn: "ডিজিটাল মার্কেটিং এবং সেলস ফানেল তৈরির আন্তর্জাতিক পেশাদার সার্টিফিকেশন।",
    category: "certifications",
    categoryEn: "Certification & Trust",
    categoryBn: "সার্টিফিকেশন ও বিশ্বাস"
  },
  {
    src: "https://i.ibb.co.com/ynyCJfG7/IMG-20260815-152407.jpg",
    titleEn: "Advanced Digital Marketing Specialist",
    titleBn: "অ্যাডভান্সড ডিজিটাল মার্কেটিং স্পেশালিস্ট",
    descEn: "Professional recognition for executing high-performing Facebook and Instagram advertising structures.",
    descBn: "ফেসবুক ও ইনস্টাগ্রামের হাই-কনভার্টিং বিজ্ঞাপন সেটআপ ও অ্যাডভান্সড ক্যাম্পেইন পরিচালনার পেশাদার স্বীকৃতি।",
    category: "certifications",
    categoryEn: "Certification & Trust",
    categoryBn: "সার্টিফিকেশন ও বিশ্বাস"
  },
  {
    src: "https://i.ibb.co.com/K4kmnfv/IMG-20260815-WA0001.jpg",
    titleEn: "Campaign Revenue & Profit Growth",
    titleBn: "ক্যাম্পেইন রেভিনিউ ও প্রফিট বৃদ্ধি",
    descEn: "Direct sales generation and ad spend returns demonstrating continuous scaling profit.",
    descBn: "গ্রাহকদের সফল সেলস বৃদ্ধি এবং সর্বনিম্ন বিজ্ঞাপনের খরচে সর্বোচ্চ লাভ নিশ্চিত করার বাস্তব প্রমাণ।",
    category: "my_profit",
    categoryEn: "My Profit",
    categoryBn: "মাই প্রফিট"
  },
  {
    src: "https://i.ibb.co.com/LzrcdnZf/IMG-20260815-WA0004.jpg",
    titleEn: "High ROI Ad Performance",
    titleBn: "উচ্চ আরওআই (ROI) অ্যাড পারফরম্যান্স",
    descEn: "Optimized ad sets producing maximum conversion values and high profit margins.",
    descBn: "বিজ্ঞাপনে সর্বোচ্চ রিটার্ন অন ইনভেস্টমেন্ট এবং ধারাবাহিক প্রফিট মার্জিনের ডাটা ড্যাশবোর্ড।",
    category: "my_profit",
    categoryEn: "My Profit",
    categoryBn: "মাই প্রফিট"
  },
  {
    src: "https://i.ibb.co.com/5gFbvLnD/IMG-20260815-WA0002.jpg",
    titleEn: "Direct Sales & Conversion Dashboards",
    titleBn: "সরাসরি সেলস ও কনভার্সন ড্যাশবোর্ড",
    descEn: "Comprehensive campaign performance tracking detailing conversion values and overall revenue.",
    descBn: "মেটা বিজ্ঞাপনের কাস্টমাইজড রিপোর্টিং ড্যাশবোর্ড যা ক্লায়েন্টের প্রকৃত সেলস এবং মুনাফা প্রদর্শন করে।",
    category: "my_profit",
    categoryEn: "My Profit",
    categoryBn: "মাই প্রফিট"
  }
];

export const defaultLogo = "https://i.ibb.co.com/cSnfRjFJ/IMG-20260815-135937.jpg";
export const defaultName = "Pashu Akter Riya";

// Hook to load live configuration
export function useLiveConfig() {
  const [logoUrl, setLogoUrl] = useState<string>(defaultLogo);
  const [siteName, setSiteName] = useState<string>(defaultName);
  const [categories, setCategories] = useState<Category[]>(defaultCategories);
  const [images, setImages] = useState<PortfolioImage[]>(defaultImages);
  const [loading, setLoading] = useState<boolean>(true);

  // 1. Sync Site Config
  useEffect(() => {
    const unsub = onSnapshot(doc(db, "configs", "site"), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        if (data.logoUrl) setLogoUrl(data.logoUrl);
        if (data.name) setSiteName(data.name);
      } else {
        // Fallback
        setLogoUrl(defaultLogo);
        setSiteName(defaultName);
      }
    }, (error) => {
      console.warn("Firestore config snapshot error (will use default logo/name):", error);
    });
    return unsub;
  }, []);

  // 2. Sync Categories
  useEffect(() => {
    const unsub = onSnapshot(collection(db, "categories"), (snap) => {
      if (!snap.empty) {
        const list: Category[] = [];
        snap.forEach((d) => {
          const data = d.data();
          list.push({
            id: d.id,
            nameEn: data.nameEn || "",
            nameBn: data.nameBn || ""
          });
        });
        setCategories(list);
      } else {
        setCategories(defaultCategories);
      }
    }, (error) => {
      console.warn("Firestore categories snapshot error (will use defaults):", error);
    });
    return unsub;
  }, []);

  // 3. Sync Images
  useEffect(() => {
    const q = query(collection(db, "images"));
    const unsub = onSnapshot(q, (snap) => {
      if (!snap.empty) {
        const list: PortfolioImage[] = [];
        snap.forEach((d) => {
          const data = d.data();
          list.push({
            id: d.id,
            src: data.src || "",
            titleEn: data.titleEn || "",
            titleBn: data.titleBn || "",
            descEn: data.descEn || "",
            descBn: data.descBn || "",
            category: data.category || "certifications",
            createdAt: data.createdAt || null
          });
        });
        setImages(list);
        setLoading(false);
      } else {
        setImages(defaultImages);
        setLoading(false);
      }
    }, (error) => {
      console.warn("Firestore images snapshot error (will use defaults):", error);
      setLoading(false);
    });
    return unsub;
  }, []);

  return { logoUrl, siteName, categories, images, loading };
}

// Function to seed initial data in Firestore if empty
export async function seedInitialData() {
  try {
    // 1. Seed Site Config
    await setDoc(doc(db, "configs", "site"), {
      logoUrl: defaultLogo,
      name: defaultName
    });

    // 2. Seed Categories
    for (const cat of defaultCategories) {
      await setDoc(doc(db, "categories", cat.id), {
        nameEn: cat.nameEn,
        nameBn: cat.nameBn
      });
    }

    // 3. Seed Images
    // Clean first
    const imageSnap = await getDocs(collection(db, "images"));
    for (const d of imageSnap.docs) {
      await deleteDoc(d.ref);
    }

    // Add default images
    for (const img of defaultImages) {
      await addDoc(collection(db, "images"), {
        src: img.src,
        titleEn: img.titleEn,
        titleBn: img.titleBn,
        descEn: img.descEn,
        descBn: img.descBn,
        category: img.category,
        createdAt: new Date().toISOString()
      });
    }
    
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, "seeds");
    return false;
  }
}

// Update Site Logo and Name
export async function updateSiteConfig(logoUrl: string, name: string) {
  try {
    await setDoc(doc(db, "configs", "site"), {
      logoUrl,
      name
    });
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, "configs/site");
    return false;
  }
}

// Add custom category
export async function addCategory(id: string, nameEn: string, nameBn: string) {
  try {
    const cleanId = id.trim().toLowerCase().replace(/[^a-z0-9_-]/g, "_");
    await setDoc(doc(db, "categories", cleanId), {
      nameEn,
      nameBn
    });
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `categories/${id}`);
    return false;
  }
}

// Remove category
export async function removeCategory(id: string) {
  try {
    await deleteDoc(doc(db, "categories", id));
    // Also delete any images belonging to that category to prevent orphans
    const q = query(collection(db, "images"));
    const snap = await getDocs(q);
    for (const d of snap.docs) {
      if (d.data().category === id) {
        await deleteDoc(d.ref);
      }
    }
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `categories/${id}`);
    return false;
  }
}

// Add portfolio image
export async function addPortfolioImage(img: Omit<PortfolioImage, "id">) {
  try {
    await addDoc(collection(db, "images"), {
      src: img.src,
      titleEn: img.titleEn,
      titleBn: img.titleBn,
      descEn: img.descEn,
      descBn: img.descBn,
      category: img.category,
      createdAt: new Date().toISOString()
    });
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, "images");
    return false;
  }
}

// Delete portfolio image
export async function deletePortfolioImage(id: string) {
  try {
    await deleteDoc(doc(db, "images", id));
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `images/${id}`);
    return false;
  }
}

export interface LeadQuery {
  id?: string;
  clientName: string;
  businessNiche: string;
  customMessage: string;
  createdAt: string;
}

// Submit a new lead query
export async function submitLeadQuery(clientName: string, businessNiche: string, customMessage: string) {
  try {
    await addDoc(collection(db, "queries"), {
      clientName,
      businessNiche: businessNiche || "",
      customMessage: customMessage || "",
      createdAt: new Date().toISOString()
    });
    return true;
  } catch (error) {
    console.error("Error submitting lead query:", error);
    return false;
  }
}

// Hook to listen to live lead queries (admin only)
export function useLiveLeads() {
  const [leads, setLeads] = useState<LeadQuery[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const q = query(collection(db, "queries"));
    const unsub = onSnapshot(q, (snap) => {
      const list: LeadQuery[] = [];
      snap.forEach((d) => {
        const data = d.data();
        list.push({
          id: d.id,
          clientName: data.clientName || "",
          businessNiche: data.businessNiche || "",
          customMessage: data.customMessage || "",
          createdAt: data.createdAt || ""
        });
      });
      // Sort by date descending
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setLeads(list);
      setLoading(false);
    }, (error) => {
      console.warn("Firestore queries snapshot error (will show empty list):", error);
      setLoading(false);
    });
    return unsub;
  }, []);

  return { leads, loading };
}

// Delete a lead query
export async function deleteLeadQuery(id: string) {
  try {
    await deleteDoc(doc(db, "queries", id));
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `queries/${id}`);
    return false;
  }
}

